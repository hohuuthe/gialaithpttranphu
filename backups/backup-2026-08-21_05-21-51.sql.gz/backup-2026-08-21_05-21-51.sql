--
-- PostgreSQL database dump
--

\restrict Cj9SycSQCubBve0IrgppadKLHFSN2JhxiM7brCvaclmipM9tmNZHTJJcTp8IGqP

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Zero-Trust: Xem dữ liệu tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Zero-Trust: Sửa dữ liệu cá nhân" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."vanban_doan";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."settings";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."phancong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."github_settings";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."doanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."settings";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép xem danh sách tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Cho phép xem danh sách tuần học" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Cho phép xem danh sách năm học" ON "public"."namhoc";
DROP POLICY IF EXISTS "Cho phép xem danh sách chi đoàn" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Cho phép xem bảng phân quyền" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."phancong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."namhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua";
DROP POLICY IF EXISTS "Admin toàn quyền quản trị bảng taikhoan" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Admin có full quyền" ON "public"."vanban_doan";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tuan_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tieu_chi_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nguoi_to_cao_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nam_hoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_doan_vien_vi_pham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_doanvien";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_baocao";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "fk_ql_baocao_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_tuan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "trg_3_dong_bo_taikhoan_sang_auth_users" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "trg_2_tu_dong_bam_mat_khau_taikhoan" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "trg_1_kiem_tra_an_ninh_taikhoan" ON "public"."taikhoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_selec";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_chidoan";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_optimization_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tuan_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_theodoi360_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_theodoi360_doanvien";
DROP INDEX IF EXISTS "public"."idx_taikhoan_username_lower";
DROP INDEX IF EXISTS "public"."idx_taikhoan_role";
DROP INDEX IF EXISTS "public"."idx_taikhoan_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_optimization_namhoc";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_doanvien";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_chidoan";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_baocao";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_namhoc_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thongke";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_hocky_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_lopcham_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_hocky";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chamlop";
DROP INDEX IF EXISTS "public"."idx_cauhinh_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_users_name";
DROP INDEX IF EXISTS "auth"."idx_users_last_sign_in_at_desc";
DROP INDEX IF EXISTS "auth"."idx_users_email";
DROP INDEX IF EXISTS "auth"."idx_users_created_at_desc";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_payload_exclusive";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_24" DROP CONSTRAINT IF EXISTS "messages_2026_08_24_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_23" DROP CONSTRAINT IF EXISTS "messages_2026_08_23_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_22" DROP CONSTRAINT IF EXISTS "messages_2026_08_22_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_21" DROP CONSTRAINT IF EXISTS "messages_2026_08_21_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_20" DROP CONSTRAINT IF EXISTS "messages_2026_08_20_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_19" DROP CONSTRAINT IF EXISTS "messages_2026_08_19_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_18" DROP CONSTRAINT IF EXISTS "messages_2026_08_18_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."vanban_doan" DROP CONSTRAINT IF EXISTS "vanban_doan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."vanban_doan" DROP CONSTRAINT IF EXISTS "vanban_doan_category_key";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "unique_xet_thidua_chidoan_hocky";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "unique_chidoan_tuan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "unique_chamdiem_record";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "unique_cauhinh_namhoc_hocky";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "thongbao_riengbiet_pkey";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_hethong" DROP CONSTRAINT IF EXISTS "thongbao_hethong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_pkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "ql_nop_bc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "ql_baocao_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_endpoint_key";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "gio_hoc_tap_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_24";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_23";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_22";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_21";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_20";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_19";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_18";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."xet_thidua";
DROP TABLE IF EXISTS "public"."vanban_doan";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."thongbao_riengbiet";
DROP TABLE IF EXISTS "public"."thongbao_hethong";
DROP TABLE IF EXISTS "public"."theodoi360";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ql_nop_bc";
DROP TABLE IF EXISTS "public"."ql_baocao";
DROP TABLE IF EXISTS "public"."push_subscriptions";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."gio_hoc_tap";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."cauhinh_tieuchi_xet_thidua";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."wal2json_escape_identifier"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."verify_and_consume_backup_code"("p_code" "text");
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."save_user_backup_codes"("p_encrypted_codes" "text");
DROP FUNCTION IF EXISTS "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid");
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]);
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "public"."get_secure_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_doanvien_id"();
DROP FUNCTION IF EXISTS "public"."get_auth_chidoan_id"();
DROP FUNCTION IF EXISTS "public"."fn_tu_dong_bam_mat_khau_taikhoan"();
DROP FUNCTION IF EXISTS "public"."fn_kiem_tra_an_ninh_taikhoan"();
DROP FUNCTION IF EXISTS "public"."fn_dong_bo_taikhoan_sang_auth_users"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_realtime_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_realtime_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text",
	"negate" boolean
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_realtime_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql("text", "text", "jsonb", "jsonb"); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION "graphql_public"."graphql"("operationName" "text" DEFAULT NULL::"text", "query" "text" DEFAULT NULL::"text", "variables" "jsonb" DEFAULT NULL::"jsonb", "extensions" "jsonb" DEFAULT NULL::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") OWNER TO "supabase_admin";

--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: fn_dong_bo_taikhoan_sang_auth_users(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $_$
DECLARE
  v_old_email text;
  v_new_email text;
  v_safe_username text;
  v_encrypted_pwd text;
  v_user_id uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_safe_username := lower(regexp_replace(COALESCE(OLD.username, ''), '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe_username <> '' THEN
      v_old_email := v_safe_username || '@htqltd.vn';
      SELECT id INTO v_user_id FROM auth.users WHERE email = v_old_email LIMIT 1;
      IF v_user_id IS NOT NULL THEN
        DELETE FROM auth.identities WHERE user_id = v_user_id;
        DELETE FROM auth.users WHERE id = v_user_id;
      ELSE
        DELETE FROM auth.users WHERE email = v_old_email;
      END IF;
    END IF;
    RETURN OLD;
  END IF;

  IF TG_OP = 'INSERT' THEN
    v_safe_username := lower(regexp_replace(COALESCE(NEW.username, ''), '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe_username = '' THEN
      v_safe_username := 'user_' || substr(md5(random()::text), 1, 8);
    END IF;
    v_new_email := v_safe_username || '@htqltd.vn';

    IF NEW.password ~ '^\$2[aby]\$' THEN
      v_encrypted_pwd := NEW.password;
    ELSIF NEW.password IS NOT NULL AND NEW.password <> '' THEN
      v_encrypted_pwd := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
    ELSE
      v_encrypted_pwd := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
    END IF;

    SELECT id INTO v_user_id FROM auth.users WHERE email = v_new_email LIMIT 1;

    IF v_user_id IS NULL THEN
      v_user_id := gen_random_uuid();

      INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token,
        email_change_token_new,
        email_change,
        phone_change,
        phone_change_token,
        email_change_token_current,
        reauthentication_token,
        is_sso_user,
        is_anonymous
      ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        v_user_id,
        'authenticated',
        'authenticated',
        v_new_email,
        v_encrypted_pwd,
        now(),
        '{"provider":"email","providers":["email"]}'::jsonb,
        json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        now(),
        now(),
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        false,
        false
      );

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    ELSE
      UPDATE auth.users
      SET
        email = v_new_email,
        encrypted_password = v_encrypted_pwd,
        raw_user_meta_data = json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        confirmation_token = COALESCE(confirmation_token, ''),
        recovery_token = COALESCE(recovery_token, ''),
        email_change_token_new = COALESCE(email_change_token_new, ''),
        email_change = COALESCE(email_change, ''),
        phone_change = COALESCE(phone_change, ''),
        phone_change_token = COALESCE(phone_change_token, ''),
        email_change_token_current = COALESCE(email_change_token_current, ''),
        reauthentication_token = COALESCE(reauthentication_token, ''),
        is_sso_user = COALESCE(is_sso_user, false),
        is_anonymous = COALESCE(is_anonymous, false),
        updated_at = now()
      WHERE id = v_user_id;

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    END IF;

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_old_email := lower(regexp_replace(COALESCE(OLD.username, ''), '[^a-zA-Z0-9_.-]', '', 'g')) || '@htqltd.vn';
    v_safe_username := lower(regexp_replace(COALESCE(NEW.username, ''), '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe_username = '' THEN
      v_safe_username := 'user_' || substr(md5(random()::text), 1, 8);
    END IF;
    v_new_email := v_safe_username || '@htqltd.vn';

    SELECT id INTO v_user_id FROM auth.users WHERE email = v_old_email OR email = v_new_email LIMIT 1;

    IF NEW.password IS DISTINCT FROM OLD.password THEN
      IF NEW.password ~ '^\$2[aby]\$' THEN
        v_encrypted_pwd := NEW.password;
      ELSIF NEW.password IS NOT NULL AND NEW.password <> '' THEN
        v_encrypted_pwd := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
      ELSE
        v_encrypted_pwd := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
      END IF;
    END IF;

    IF v_user_id IS NOT NULL THEN
      UPDATE auth.users
      SET
        email = v_new_email,
        encrypted_password = CASE 
          WHEN v_encrypted_pwd IS NOT NULL THEN v_encrypted_pwd 
          ELSE encrypted_password 
        END,
        raw_user_meta_data = json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        confirmation_token = COALESCE(confirmation_token, ''),
        recovery_token = COALESCE(recovery_token, ''),
        email_change_token_new = COALESCE(email_change_token_new, ''),
        email_change = COALESCE(email_change, ''),
        phone_change = COALESCE(phone_change, ''),
        phone_change_token = COALESCE(phone_change_token, ''),
        email_change_token_current = COALESCE(email_change_token_current, ''),
        reauthentication_token = COALESCE(reauthentication_token, ''),
        is_sso_user = COALESCE(is_sso_user, false),
        is_anonymous = COALESCE(is_anonymous, false),
        updated_at = now()
      WHERE id = v_user_id;

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    ELSE
      v_user_id := gen_random_uuid();
      IF v_encrypted_pwd IS NULL THEN
        IF NEW.password ~ '^\$2[aby]\$' THEN
          v_encrypted_pwd := NEW.password;
        ELSIF NEW.password IS NOT NULL AND NEW.password <> '' THEN
          v_encrypted_pwd := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
        ELSE
          v_encrypted_pwd := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
        END IF;
      END IF;

      INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token,
        email_change_token_new,
        email_change,
        phone_change,
        phone_change_token,
        email_change_token_current,
        reauthentication_token,
        is_sso_user,
        is_anonymous
      ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        v_user_id,
        'authenticated',
        'authenticated',
        v_new_email,
        v_encrypted_pwd,
        now(),
        '{"provider":"email","providers":["email"]}'::jsonb,
        json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        now(),
        now(),
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        false,
        false
      );

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$_$;


ALTER FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() OWNER TO "postgres";

--
-- Name: fn_kiem_tra_an_ninh_taikhoan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth'
    AS $$
DECLARE
  v_current_auth_role text;
  v_current_user_email text;
  v_operator_role text;
  v_target_role_upper text;
  v_is_db_admin boolean;
BEGIN
  v_is_db_admin := (current_user IN ('postgres', 'service_role', 'supabase_admin'));
  v_current_auth_role := COALESCE(auth.role(), 'anon');
  v_current_user_email := COALESCE(auth.email(), '');

  IF NOT v_is_db_admin AND v_current_auth_role = 'anon' THEN
    RAISE EXCEPTION 'BAO MAT CANH BAO: Nghiem cam tao, sua doi hoac xoa tai khoan tu API ben ngoai!';
  END IF;

  IF NOT v_is_db_admin THEN
    SELECT upper(trim(role)) INTO v_operator_role
    FROM public.taikhoan
    WHERE id = auth.uid() 
       OR lower(regexp_replace(username, '[^a-zA-Z0-9_.-]', '', 'g')) || '@htqltd.vn' = lower(v_current_user_email)
       OR lower(username) = split_part(lower(v_current_user_email), '@', 1)
    LIMIT 1;
  ELSE
    v_operator_role := 'ADMIN';
  END IF;

  IF TG_OP = 'DELETE' THEN
    IF lower(trim(OLD.username)) = 'admin' THEN
      RAISE EXCEPTION 'BAO MAT: Nghiem cam xoa tai khoan Admin goc cua he thong!';
    END IF;

    IF NOT v_is_db_admin AND (v_operator_role IS NULL OR v_operator_role <> 'ADMIN') THEN
      RAISE EXCEPTION 'BAO MAT: Ban khong co quyen xoa tai khoan!';
    END IF;

    RETURN OLD;
  END IF;

  IF TG_OP IN ('INSERT', 'UPDATE') THEN
    v_target_role_upper := upper(trim(COALESCE(NEW.role, 'DV')));

    IF TG_OP = 'UPDATE' AND lower(trim(OLD.username)) = 'admin' THEN
      IF lower(trim(NEW.username)) <> 'admin' OR v_target_role_upper <> 'ADMIN' THEN
        RAISE EXCEPTION 'BAO MAT: Khong duoc phep doi ten hoac ha quyen cua tai khoan Admin goc!';
      END IF;
    END IF;

    IF v_target_role_upper IN ('ADMIN', 'BTV', 'BGH') THEN
      IF TG_OP = 'UPDATE' AND upper(trim(COALESCE(OLD.role, ''))) = v_target_role_upper THEN
        NULL;
      ELSIF NOT v_is_db_admin AND (v_operator_role IS NULL OR v_operator_role <> 'ADMIN') THEN
        RAISE EXCEPTION 'BAO MAT: Chi co Quan tri vien (Admin) moi co quyen cap quyen Quan tri (Admin/BTV/BGH)!';
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() OWNER TO "postgres";

--
-- Name: fn_tu_dong_bam_mat_khau_taikhoan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'extensions'
    AS $_$
BEGIN
  IF TG_OP = 'INSERT' OR (TG_OP = 'UPDATE' AND NEW.password IS DISTINCT FROM OLD.password) THEN
    IF NEW.password IS NULL OR trim(NEW.password) = '' THEN
      NEW.password := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
    ELSIF NOT (NEW.password ~ '^\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53}$') THEN
      NEW.password := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
    END IF;
  END IF;

  RETURN NEW;
END;
$_$;


ALTER FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() OWNER TO "postgres";

--
-- Name: get_auth_chidoan_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_chidoan_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT chidoan_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_chidoan_id"() OWNER TO "postgres";

--
-- Name: get_auth_doanvien_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_doanvien_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT doanvien_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_doanvien_id"() OWNER TO "postgres";

--
-- Name: get_auth_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_role"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    AS $$
DECLARE
  v_role text;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  -- 1. Tìm theo auth.uid() trong bảng taikhoan
  SELECT role INTO v_role
  FROM public.taikhoan
  WHERE id = auth.uid()
  LIMIT 1;

  -- 2. Nếu chưa khớp id, tìm theo username/email
  IF v_role IS NULL THEN
    SELECT role INTO v_role
    FROM public.taikhoan
    WHERE lower(username) = lower(split_part(coalesce(auth.email(), ''), '@', 1))
       OR lower(username) = lower(coalesce(auth.jwt() ->> 'preferred_username', ''))
       OR lower(username) = lower(coalesce(auth.jwt() -> 'user_metadata' ->> 'username', ''))
    LIMIT 1;
  END IF;

  -- 3. Nếu vẫn chưa có, lấy từ metadata của Supabase Auth
  IF v_role IS NULL THEN
    v_role := (auth.jwt() -> 'user_metadata' ->> 'role');
  END IF;

  -- Luôn chuyển đổi về chữ thường để so sánh an toàn tuyệt đối
  RETURN lower(coalesce(v_role, 'guest'));
END;
$$;


ALTER FUNCTION "public"."get_auth_role"() OWNER TO "postgres";

--
-- Name: get_secure_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_secure_role"() RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_secure_role"() OWNER TO "postgres";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

--
-- Name: rpc_delete_auth_users_by_usernames("text"[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $$
DECLARE
  v_uname text;
  v_safe text;
  v_emails text[] := '{}';
BEGIN
  IF p_usernames IS NULL OR array_length(p_usernames, 1) IS NULL THEN
    RETURN;
  END IF;

  FOREACH v_uname IN ARRAY p_usernames LOOP
    v_safe := lower(regexp_replace(v_uname, '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe <> '' THEN
      v_emails := array_append(v_emails, v_safe || '@htqltd.vn');
      v_emails := array_append(v_emails, v_safe || '@%');
    END IF;
  END LOOP;

  -- Xóa chính xác các người dùng tương ứng trong auth.users
  DELETE FROM auth.users WHERE email = ANY(v_emails) OR email ILIKE ANY(v_emails);
END;
$$;


ALTER FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "doanvien_id" "uuid",
    "sl_dangnhap" integer DEFAULT 0,
    "tg_truycap" timestamp with time zone,
    "chidoan1111" "text"
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT * FROM public.taikhoan 
  WHERE username = p_username 
  LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: rpc_tao_tai_khoan_an_toan("text", "text", "text", "text", "uuid", "uuid"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text" DEFAULT 'DV'::"text", "p_chidoan_id" "uuid" DEFAULT NULL::"uuid", "p_doanvien_id" "uuid" DEFAULT NULL::"uuid") RETURNS json
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $$
DECLARE
  v_clean_username text;
  v_role_upper text;
  v_caller_role text;
  v_new_id uuid;
  v_is_db_admin boolean;
BEGIN
  v_is_db_admin := (current_user IN ('postgres', 'service_role', 'supabase_admin'));
  v_clean_username := lower(trim(p_username));
  v_role_upper := upper(trim(COALESCE(p_role, 'DV')));

  IF v_clean_username = '' OR p_password = '' THEN
    RETURN json_build_object('success', false, 'message', 'Ten dang nhap va mat khau khong duoc de trong.');
  END IF;

  IF EXISTS (SELECT 1 FROM public.taikhoan WHERE lower(username) = v_clean_username) THEN
    RETURN json_build_object('success', false, 'message', 'Ten dang nhap da ton tai trong he thong.');
  END IF;

  IF NOT v_is_db_admin AND v_role_upper IN ('ADMIN', 'BTV', 'BGH') THEN
    SELECT upper(trim(role)) INTO v_caller_role
    FROM public.taikhoan
    WHERE id = auth.uid() 
       OR lower(regexp_replace(username, '[^a-zA-Z0-9_.-]', '', 'g')) || '@htqltd.vn' = lower(COALESCE(auth.email(), ''))
       OR lower(username) = split_part(lower(COALESCE(auth.email(), '')), '@', 1)
    LIMIT 1;

    IF v_caller_role IS NULL OR v_caller_role <> 'ADMIN' THEN
      RETURN json_build_object('success', false, 'message', 'Tu choi: Ban khong co quyen tao tai khoan Quan tri vien!');
    END IF;
  END IF;

  v_new_id := gen_random_uuid();

  INSERT INTO public.taikhoan (
    id, username, password, fullname, role, chidoan_id, doanvien_id
  ) VALUES (
    v_new_id, p_username, p_password, p_fullname, p_role, p_chidoan_id, p_doanvien_id
  );

  RETURN json_build_object('success', true, 'message', 'Tao tai khoan thanh cong.', 'id', v_new_id);
END;
$$;


ALTER FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") OWNER TO "postgres";

--
-- Name: save_user_backup_codes("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text := coalesce(auth.email(), '');
  v_username text := lower(split_part(v_email, '@', 1));
BEGIN
  IF v_uid IS NULL THEN
    RETURN false;
  END IF;

  -- Cập nhật trực tiếp vào bảng taikhoan dựa theo ID hoặc Username/Email
  UPDATE public.taikhoan
  SET 
    chidoan1111 = p_encrypted_codes,
    updatedat = now()
  WHERE id = v_uid 
     OR lower(username) = v_username;

  RETURN true;
END;
$$;


ALTER FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: verify_and_consume_backup_code("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_chidoan text;
  v_clean_input text;
  v_remaining_count int := 0;
BEGIN
  IF v_uid IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Chưa đăng nhập');
  END IF;

  v_clean_input := upper(regexp_replace(coalesce(p_code, ''), '[^A-Z0-9]', '', 'g'));
  IF length(v_clean_input) < 6 THEN
    RETURN jsonb_build_object('success', false, 'message', 'Mã không hợp lệ');
  END IF;

  -- Lấy chuỗi cấu hình 2FA hiện tại của tài khoản
  SELECT chidoan1111 INTO v_chidoan 
  FROM public.taikhoan 
  WHERE id = v_uid 
  LIMIT 1;

  IF v_chidoan IS NULL OR v_chidoan NOT LIKE '2FA:true:%' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Tài khoản chưa cấu hình mã dự phòng');
  END IF;

  -- Ghi nhận thời điểm xác thực hợp lệ
  UPDATE public.taikhoan
  SET updatedat = now()
  WHERE id = v_uid;

  RETURN jsonb_build_object(
    'success', true, 
    'message', 'Xác thực mã dự phòng thành công',
    'remaining_count', 7
  );
END;
$$;


ALTER FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) RETURNS boolean
    LANGUAGE "plpgsql" STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_realtime_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: send_binary("bytea", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_realtime_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: wal2json_escape_identifier("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "custom_claims_allowlist" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."cauhinh_tieuchi_xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "ten_tieuchi_1" character varying(255) DEFAULT 'Tiêu chí 1'::character varying,
    "sudung_1" boolean DEFAULT true,
    "kieudulieu_1" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_2" character varying(255) DEFAULT 'Tiêu chí 2'::character varying,
    "sudung_2" boolean DEFAULT true,
    "kieudulieu_2" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_3" character varying(255) DEFAULT 'Tiêu chí 3'::character varying,
    "sudung_3" boolean DEFAULT true,
    "kieudulieu_3" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_4" character varying(255) DEFAULT 'Tiêu chí 4'::character varying,
    "sudung_4" boolean DEFAULT true,
    "kieudulieu_4" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_5" character varying(255) DEFAULT 'Tiêu chí 5'::character varying,
    "sudung_5" boolean DEFAULT true,
    "kieudulieu_5" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_6" character varying(255) DEFAULT 'Tiêu chí 6'::character varying,
    "sudung_6" boolean DEFAULT false,
    "kieudulieu_6" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_7" character varying(255) DEFAULT 'Tiêu chí 7'::character varying,
    "sudung_7" boolean DEFAULT false,
    "kieudulieu_7" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_8" character varying(255) DEFAULT 'Tiêu chí 8'::character varying,
    "sudung_8" boolean DEFAULT false,
    "kieudulieu_8" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_9" character varying(255) DEFAULT 'Tiêu chí 9'::character varying,
    "sudung_9" boolean DEFAULT false,
    "kieudulieu_9" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_10" character varying(255) DEFAULT 'Tiêu chí 10'::character varying,
    "sudung_10" boolean DEFAULT false,
    "kieudulieu_10" character varying(20) DEFAULT 'NUMBER'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "ghi_chu" "text",
    "giai_thich" "text",
    "trang_thai" character varying(30) DEFAULT 'dang_xet'::character varying,
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY ((ARRAY['HK1'::character varying, 'HK2'::character varying, 'CA_NAM'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_10_check" CHECK ((("kieudulieu_10")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_1_check" CHECK ((("kieudulieu_1")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_2_check" CHECK ((("kieudulieu_2")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_3_check" CHECK ((("kieudulieu_3")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_4_check" CHECK ((("kieudulieu_4")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_5_check" CHECK ((("kieudulieu_5")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_6_check" CHECK ((("kieudulieu_6")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_7_check" CHECK ((("kieudulieu_7")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_8_check" CHECK ((("kieudulieu_8")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_9_check" CHECK ((("kieudulieu_9")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "chk_cauhinh_trang_thai" CHECK ((("trang_thai")::"text" = ANY ((ARRAY['dang_xet'::character varying, 'ban_du_thao'::character varying, 'ban_cong_bo'::character varying])::"text"[])))
);


ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "sothedoan" "text",
    "phuongtien" "text",
    "thongtinphuongtien" "text"
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: COLUMN "doanvien"."sothedoan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."doanvien"."sothedoan" IS 'Số thẻ đoàn viên';


--
-- Name: COLUMN "doanvien"."phuongtien"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."doanvien"."phuongtien" IS 'Sử dụng phương tiện di chuyển';


--
-- Name: COLUMN "doanvien"."thongtinphuongtien"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."doanvien"."thongtinphuongtien" IS 'Thông tin phương tiện (Biển số xe, nhãn hiệu/màu sắc...)';


--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: gio_hoc_tap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."gio_hoc_tap" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "so_tot" integer DEFAULT 0,
    "so_kha" integer DEFAULT 0,
    "so_tb" integer DEFAULT 0,
    "so_yeu" integer DEFAULT 0,
    "diem_tot_cauhinh" numeric DEFAULT 10,
    "diem_kha_cauhinh" numeric DEFAULT 7,
    "diem_tb_cauhinh" numeric DEFAULT 4,
    "diem_yeu_cauhinh" numeric DEFAULT 1,
    "diem_tb_hoc_tap" numeric(5,2) DEFAULT 0.00,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()),
    "hocky" "text"
);


ALTER TABLE "public"."gio_hoc_tap" OWNER TO "postgres";

--
-- Name: TABLE "gio_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."gio_hoc_tap" IS 'Bảng quản lý giờ học tập và điểm trung bình học tập của Chi đoàn theo tuần và năm học';


--
-- Name: COLUMN "gio_hoc_tap"."namhoc_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."namhoc_id" IS 'Liên kết với năm học hiện tại';


--
-- Name: COLUMN "gio_hoc_tap"."chidoan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."chidoan_id" IS 'Liên kết với Chi đoàn được xếp loại giờ học';


--
-- Name: COLUMN "gio_hoc_tap"."tuan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."tuan_id" IS 'Liên kết với tuần học tương ứng';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tot_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tot_cauhinh" IS 'Điểm cấu hình của giờ Tốt tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_kha_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_kha_cauhinh" IS 'Điểm cấu hình của giờ Khá tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_cauhinh" IS 'Điểm cấu hình của giờ Trung bình tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_yeu_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_yeu_cauhinh" IS 'Điểm cấu hình của giờ Yếu tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_hoc_tap" IS 'Điểm trung bình học tập thực tế cuối cùng của tuần';


--
-- Name: COLUMN "gio_hoc_tap"."hocky"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."hocky" IS 'Học kỳ diễn ra tuần học tập (ví dụ: HK1, HK2)';


--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "isdefault" boolean DEFAULT false
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "giai_thich" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."push_subscriptions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text",
    "chidoan_id" "uuid",
    "subscription" "jsonb" NOT NULL,
    "endpoint" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."push_subscriptions" OWNER TO "postgres";

--
-- Name: ql_baocao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_baocao" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "chu_de" "text" NOT NULL,
    "chu_de_phu" "text",
    "tu_ngay" "date",
    "den_ngay" "date",
    "cho_phep_minh_chung" boolean DEFAULT true,
    "doi_tuong_nop" "text",
    "huong_dan" "text",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "nam_hoc_id" "uuid",
    "hoc_ky" "text",
    "config_noi_dung1" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 1", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung2" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 2", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung3" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 3", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung4" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 4", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung5" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 5", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung6" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 6", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung7" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 7", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung8" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 8", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung9" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 9", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung10" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 10", "enabled": true, "options": "", "required": false}'::"jsonb",
    "allowed_file_types" "text" DEFAULT 'image,video,pdf,doc'::"text",
    "max_file_size" integer DEFAULT 10
);


ALTER TABLE "public"."ql_baocao" OWNER TO "postgres";

--
-- Name: COLUMN "ql_baocao"."config_noi_dung1"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung1" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 1';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung2" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 2';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung3"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung3" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 3';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung4"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung4" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 4';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung5"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung5" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 5';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung6"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung6" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 6';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung7"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung7" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 7';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung8"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung8" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 8';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung9"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung9" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 9';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung10"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung10" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 10';


--
-- Name: ql_nop_bc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_nop_bc" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ql_bao_cao_id" "uuid" NOT NULL,
    "doanvien_id" "uuid",
    "noi_dung1" "text",
    "noi_dung2" "text",
    "noi_dung3" "text",
    "noi_dung4" "text",
    "noi_dung5" "text",
    "noi_dung6" "text",
    "noi_dung7" "text",
    "noi_dung8" "text",
    "noi_dung9" "text",
    "noi_dung10" "text",
    "duong_dan_minh_chung" "text",
    "ghi_chu" "text",
    "trang_thai" "text",
    "ngay_capnhat" timestamp with time zone DEFAULT "now"(),
    "chi_doan_id" "uuid",
    "danh_sach_anh" "text",
    "vaitro_nop" "text",
    "doituong_nop" "text",
    "nguoi_tao_id" "text"
);


ALTER TABLE "public"."ql_nop_bc" OWNER TO "postgres";

--
-- Name: COLUMN "ql_nop_bc"."danh_sach_anh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_nop_bc"."danh_sach_anh" IS 'Danh sách liên kết các ảnh minh chứng tải lên R2, phân tách bằng dấu phẩy';


--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "he_so_tru" numeric DEFAULT 1,
    "he_so_cong" numeric DEFAULT 1
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: COLUMN "qlchidoan"."he_so_tru"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_tru" IS 'Hệ số nhân điểm trừ riêng biệt cho từng Chi đoàn';


--
-- Name: COLUMN "qlchidoan"."he_so_cong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_cong" IS 'Hệ số nhân điểm cộng riêng biệt cho từng Chi đoàn';


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "cloudinary_cloud_name" "text",
    "cloudinary_upload_preset" "text",
    "cloudinary_api_key" "text",
    "cloudinary_api_secret" "text",
    "r2_account_id" "text",
    "r2_access_key_id" "text",
    "r2_secret_access_key" "text",
    "r2_bucket_name" "text",
    "r2_custom_domain" "text",
    "show_class_select_gvcn" "text" DEFAULT 'Không hiển thị'::"text",
    "diem_tot" numeric DEFAULT 10,
    "diem_kha" numeric DEFAULT 7,
    "diem_tb" numeric DEFAULT 4,
    "diem_yeu" numeric DEFAULT 1,
    "ti_trong_diem_tuan" numeric DEFAULT 50,
    "ti_trong_diem_hoc_tap" numeric DEFAULT 50
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: COLUMN "settings"."diem_tot"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tot" IS 'Điểm cấu hình mặc định cho giờ Tốt (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_kha"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_kha" IS 'Điểm cấu hình mặc định cho giờ Khá (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_tb"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tb" IS 'Điểm cấu hình mặc định cho giờ Trung bình (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_yeu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_yeu" IS 'Điểm cấu hình mặc định cho giờ Yếu (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."ti_trong_diem_tuan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_tuan" IS 'Tỉ trọng % đóng góp của điểm tuần (trừ vi phạm) vào tổng điểm thi đua chung';


--
-- Name: COLUMN "settings"."ti_trong_diem_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_hoc_tap" IS 'Tỉ trọng % đóng góp của điểm trung bình giờ học tập vào tổng điểm thi đua chung';


--
-- Name: theodoi360; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."theodoi360" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nguoi_to_cao_id" "uuid" NOT NULL,
    "doan_vien_vi_pham_id" "uuid" NOT NULL,
    "tieu_chi_id" "uuid" NOT NULL,
    "chi_tiet_vi_pham" "text",
    "danh_sach_hinh_anh" "jsonb" DEFAULT '[]'::"jsonb",
    "url_video" "text",
    "trang_thai" "text" DEFAULT 'cho_duyet'::"text",
    "nam_hoc_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "ngay_vi_pham" "date",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "hoc_ky" "text",
    "phan_hoi_bi_to_cao" "text",
    "phan_hoi_lop" "text",
    "minh_chung_drive" "text"
);


ALTER TABLE "public"."theodoi360" OWNER TO "postgres";

--
-- Name: thongbao_hethong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_hethong" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "sender" "text" DEFAULT 'Hệ thống'::"text",
    "target_role" "text" DEFAULT 'all'::"text",
    "target_chidoan_id" "uuid",
    "target_user_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_hethong" OWNER TO "postgres";

--
-- Name: thongbao_riengbiet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_riengbiet" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "text" NOT NULL,
    "sender_id" "text" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_role" "text" NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "attachments" "jsonb" DEFAULT '[]'::"jsonb",
    "target_roles" "text"[] DEFAULT '{}'::"text"[],
    "target_chidoan_ids" "text"[] DEFAULT '{}'::"text"[],
    "start_at" timestamp with time zone NOT NULL,
    "end_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "read_by" "text"[] DEFAULT '{}'::"text"[]
);


ALTER TABLE "public"."thongbao_riengbiet" OWNER TO "postgres";

--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: vanban_doan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."vanban_doan" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "category" character varying(50) NOT NULL,
    "title" character varying(255) NOT NULL,
    "drive_link" "text" DEFAULT ''::"text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE "public"."vanban_doan" OWNER TO "postgres";

--
-- Name: xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tong_diem_cham_tuan" numeric(10,2) DEFAULT 0,
    "tieuchi_1" "text" DEFAULT ''::"text",
    "tieuchi_2" "text" DEFAULT ''::"text",
    "tieuchi_3" "text" DEFAULT ''::"text",
    "tieuchi_4" "text" DEFAULT ''::"text",
    "tieuchi_5" "text" DEFAULT ''::"text",
    "tieuchi_6" "text" DEFAULT ''::"text",
    "tieuchi_7" "text" DEFAULT ''::"text",
    "tieuchi_8" "text" DEFAULT ''::"text",
    "tieuchi_9" "text" DEFAULT ''::"text",
    "tieuchi_10" "text" DEFAULT ''::"text",
    "tong_diem" numeric(10,2) DEFAULT 0,
    "xep_hang" integer,
    "danh_hieu_thi_dua" character varying(255) DEFAULT ''::character varying,
    "ghi_chu" "text" DEFAULT ''::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY ((ARRAY['HK1'::character varying, 'HK2'::character varying, 'CA_NAM'::character varying])::"text"[])))
);


ALTER TABLE "public"."xet_thidua" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_18; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_18" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_18" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_19; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_19" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_19" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_20; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_20" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_20" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_21; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_21" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_21" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_22; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_22" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_22" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_23; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_23" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_23" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_24; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_24" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_24" OWNER TO "supabase_realtime_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone DEFAULT "now"()
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    "selected_columns" "text"[],
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL,
    "versioning_status" "text" DEFAULT 'DISABLED'::"text" NOT NULL,
    CONSTRAINT "buckets_versioning_dark_check" CHECK (("versioning_status" = 'DISABLED'::"text")),
    CONSTRAINT "buckets_versioning_standard_only_check" CHECK ((("type" = 'STANDARD'::"storage"."buckettype") OR ("versioning_status" = 'DISABLED'::"text"))),
    CONSTRAINT "buckets_versioning_status_check" CHECK (("versioning_status" = ANY (ARRAY['DISABLED'::"text", 'ENABLED'::"text", 'SUSPENDED'::"text"])))
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb",
    "archived_at" timestamp with time zone,
    "is_delete_marker" boolean DEFAULT false NOT NULL,
    "is_versioned" boolean DEFAULT false NOT NULL
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_08_18; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_18" FOR VALUES FROM ('2026-08-18 00:00:00') TO ('2026-08-19 00:00:00');


--
-- Name: messages_2026_08_19; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_19" FOR VALUES FROM ('2026-08-19 00:00:00') TO ('2026-08-20 00:00:00');


--
-- Name: messages_2026_08_20; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_20" FOR VALUES FROM ('2026-08-20 00:00:00') TO ('2026-08-21 00:00:00');


--
-- Name: messages_2026_08_21; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_21" FOR VALUES FROM ('2026-08-21 00:00:00') TO ('2026-08-22 00:00:00');


--
-- Name: messages_2026_08_22; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_22" FOR VALUES FROM ('2026-08-22 00:00:00') TO ('2026-08-23 00:00:00');


--
-- Name: messages_2026_08_23; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_23" FOR VALUES FROM ('2026-08-23 00:00:00') TO ('2026-08-24 00:00:00');


--
-- Name: messages_2026_08_24; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_24" FOR VALUES FROM ('2026-08-24 00:00:00') TO ('2026-08-25 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
877693ae-8c6c-45bf-960c-12b1faae2c56	877693ae-8c6c-45bf-960c-12b1faae2c56	{"sub": "877693ae-8c6c-45bf-960c-12b1faae2c56", "email": "admin@schms4o1j90uxhk.com", "email_verified": false, "phone_verified": false}	email	2026-07-28 13:03:23.378644+00	2026-07-28 13:03:23.378701+00	2026-07-28 13:03:23.378701+00	40458adb-a466-41a4-b516-67675b7ec8c5
b37f2829-c65a-48f9-a332-de9677f7732c	b37f2829-c65a-48f9-a332-de9677f7732c	{"sub": "b37f2829-c65a-48f9-a332-de9677f7732c", "email": "nguyenbuingocdat@schms4o1j90uxhk.com", "email_verified": false, "phone_verified": false}	email	2026-07-28 14:02:11.357162+00	2026-07-28 14:02:11.357346+00	2026-07-28 14:02:11.357346+00	bd72d05f-fc62-4218-afea-9aa150751273
7538ae71-cb90-4191-8bd3-349b2e92dc14	7538ae71-cb90-4191-8bd3-349b2e92dc14	{"sub": "7538ae71-cb90-4191-8bd3-349b2e92dc14", "email": "admin@htqltd.vn", "email_verified": false, "phone_verified": false}	email	2026-08-15 08:06:38.306573+00	2026-08-15 08:06:38.306644+00	2026-08-15 08:06:38.306644+00	86f9a150-e7c2-41b9-ba35-b995da297863
admin@htqltd.vn	7538ae71-cb90-4191-8bd3-349b2e92dc14	{"sub": "7538ae71-cb90-4191-8bd3-349b2e92dc14", "email": "admin@htqltd.vn"}	email	2026-08-19 13:56:54.840176+00	2026-08-19 13:56:54.840176+00	2026-08-19 13:56:54.840176+00	7538ae71-cb90-4191-8bd3-349b2e92dc14
nguyenphamduonganha930g@htqltd.vn	571016d6-2fad-430b-aefb-777f161bd79a	{"sub": "571016d6-2fad-430b-aefb-777f161bd79a", "email": "nguyenphamduonganha930g@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	571016d6-2fad-430b-aefb-777f161bd79a
nguyenphamvanbe8sog1@htqltd.vn	6d408d6d-8d8c-4aec-a5a1-5ab03975889a	{"sub": "6d408d6d-8d8c-4aec-a5a1-5ab03975889a", "email": "nguyenphamvanbe8sog1@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	6d408d6d-8d8c-4aec-a5a1-5ab03975889a
nguyenluongthanhbinh3teye@htqltd.vn	3b148c8a-7cd1-4481-b3de-d31363b5eb1b	{"sub": "3b148c8a-7cd1-4481-b3de-d31363b5eb1b", "email": "nguyenluongthanhbinh3teye@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	3b148c8a-7cd1-4481-b3de-d31363b5eb1b
nguyenbuingocdat8gnrg@htqltd.vn	be9acf02-5690-4daa-90f6-61b4ea1e806e	{"sub": "be9acf02-5690-4daa-90f6-61b4ea1e806e", "email": "nguyenbuingocdat8gnrg@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	be9acf02-5690-4daa-90f6-61b4ea1e806e
nguyentrankhanhha13u6r@htqltd.vn	cec65c10-9bd9-45df-9d5c-5b35dfcf1006	{"sub": "cec65c10-9bd9-45df-9d5c-5b35dfcf1006", "email": "nguyentrankhanhha13u6r@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	cec65c10-9bd9-45df-9d5c-5b35dfcf1006
nguyennguyenconghau1tdht@htqltd.vn	c99cfa85-9762-4bc1-a8f7-0723ab12915a	{"sub": "c99cfa85-9762-4bc1-a8f7-0723ab12915a", "email": "nguyennguyenconghau1tdht@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	c99cfa85-9762-4bc1-a8f7-0723ab12915a
nguyennguyenduchieua2mrs@htqltd.vn	a08cd0f4-4c6d-4d17-9713-c1ed49f1c104	{"sub": "a08cd0f4-4c6d-4d17-9713-c1ed49f1c104", "email": "nguyennguyenduchieua2mrs@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	a08cd0f4-4c6d-4d17-9713-c1ed49f1c104
nguyennguyenvanhieuwrgtd@htqltd.vn	639d8d64-f28f-4625-9f09-7eee1c053421	{"sub": "639d8d64-f28f-4625-9f09-7eee1c053421", "email": "nguyennguyenvanhieuwrgtd@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	639d8d64-f28f-4625-9f09-7eee1c053421
nguyenlethithuyhoaivi8db@htqltd.vn	f11d8f73-bce0-4132-a33c-79e9449c8512	{"sub": "f11d8f73-bce0-4132-a33c-79e9449c8512", "email": "nguyenlethithuyhoaivi8db@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	f11d8f73-bce0-4132-a33c-79e9449c8512
nguyendinhngockhanhhuyen9b58d@htqltd.vn	dd996984-dc67-43d0-b2f9-7464dddcff6f	{"sub": "dd996984-dc67-43d0-b2f9-7464dddcff6f", "email": "nguyendinhngockhanhhuyen9b58d@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	dd996984-dc67-43d0-b2f9-7464dddcff6f
nguyenphamquochungvvlvo@htqltd.vn	bf42d522-5568-4e42-b5c1-13b67d01957a	{"sub": "bf42d522-5568-4e42-b5c1-13b67d01957a", "email": "nguyenphamquochungvvlvo@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	bf42d522-5568-4e42-b5c1-13b67d01957a
nguyendaovietkhanhtr1t8@htqltd.vn	4153fa98-e8e8-44bf-a96a-caba5a82045d	{"sub": "4153fa98-e8e8-44bf-a96a-caba5a82045d", "email": "nguyendaovietkhanhtr1t8@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	4153fa98-e8e8-44bf-a96a-caba5a82045d
nguyennguyenquangkien45rpt@htqltd.vn	e3753456-573b-44da-ba5e-e1332a9e366a	{"sub": "e3753456-573b-44da-ba5e-e1332a9e366a", "email": "nguyennguyenquangkien45rpt@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	e3753456-573b-44da-ba5e-e1332a9e366a
nguyennguyenkhanhlinhi8sub@htqltd.vn	b8da3dd3-5792-4861-b7c4-f9be27e75cb9	{"sub": "b8da3dd3-5792-4861-b7c4-f9be27e75cb9", "email": "nguyennguyenkhanhlinhi8sub@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	b8da3dd3-5792-4861-b7c4-f9be27e75cb9
nguyennguyenphilongq79ue@htqltd.vn	d6575387-b6c6-485e-b9f9-73ef03d070bb	{"sub": "d6575387-b6c6-485e-b9f9-73ef03d070bb", "email": "nguyennguyenphilongq79ue@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	d6575387-b6c6-485e-b9f9-73ef03d070bb
nguyentranducluong9x5gv@htqltd.vn	249781d9-5a7d-46fb-8775-45a1cfde70c7	{"sub": "249781d9-5a7d-46fb-8775-45a1cfde70c7", "email": "nguyentranducluong9x5gv@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	249781d9-5a7d-46fb-8775-45a1cfde70c7
nguyenhothikhanhlyl54h1@htqltd.vn	058679cf-8e32-4d72-ad03-271754722ce7	{"sub": "058679cf-8e32-4d72-ad03-271754722ce7", "email": "nguyenhothikhanhlyl54h1@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	058679cf-8e32-4d72-ad03-271754722ce7
nguyennguyenhoangbaominhgqeu6@htqltd.vn	5fbbab1e-ef9a-48ca-92c1-da568e5d06c9	{"sub": "5fbbab1e-ef9a-48ca-92c1-da568e5d06c9", "email": "nguyennguyenhoangbaominhgqeu6@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	5fbbab1e-ef9a-48ca-92c1-da568e5d06c9
nguyenhothungaq2o4x@htqltd.vn	6fe2212a-a4fc-4249-832a-560c7e7c0690	{"sub": "6fe2212a-a4fc-4249-832a-560c7e7c0690", "email": "nguyenhothungaq2o4x@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	6fe2212a-a4fc-4249-832a-560c7e7c0690
nguyentrinhthihangngam4gxp@htqltd.vn	3de1a592-b252-4f60-a587-30bb78d216c7	{"sub": "3de1a592-b252-4f60-a587-30bb78d216c7", "email": "nguyentrinhthihangngam4gxp@htqltd.vn"}	email	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	3de1a592-b252-4f60-a587-30bb78d216c7
nguyennguyenlucngan0e0uw@htqltd.vn	01ea9826-d1bf-415d-9755-865e99819af6	{"sub": "01ea9826-d1bf-415d-9755-865e99819af6", "email": "nguyennguyenlucngan0e0uw@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	01ea9826-d1bf-415d-9755-865e99819af6
nguyenlehoangmyngocosom0@htqltd.vn	72c338a9-df22-4f28-9593-3307a2746b28	{"sub": "72c338a9-df22-4f28-9593-3307a2746b28", "email": "nguyenlehoangmyngocosom0@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	72c338a9-df22-4f28-9593-3307a2746b28
nguyenlethibaongocmquay@htqltd.vn	102c96c5-21aa-4aec-82c5-c25267ba2f0b	{"sub": "102c96c5-21aa-4aec-82c5-c25267ba2f0b", "email": "nguyenlethibaongocmquay@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	102c96c5-21aa-4aec-82c5-c25267ba2f0b
nguyencaoanhnhanwfjao@htqltd.vn	6c8609fd-dd6e-4c5e-90a3-82fa5adb59ea	{"sub": "6c8609fd-dd6e-4c5e-90a3-82fa5adb59ea", "email": "nguyencaoanhnhanwfjao@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	6c8609fd-dd6e-4c5e-90a3-82fa5adb59ea
nguyenlevothanhnhatm5pc8@htqltd.vn	f80ab2d3-09a6-4241-a70b-e015fa0e0e2a	{"sub": "f80ab2d3-09a6-4241-a70b-e015fa0e0e2a", "email": "nguyenlevothanhnhatm5pc8@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	f80ab2d3-09a6-4241-a70b-e015fa0e0e2a
nguyendangthithuphuongy7ott@htqltd.vn	527722d1-c1d8-4371-8d05-27255ea29959	{"sub": "527722d1-c1d8-4371-8d05-27255ea29959", "email": "nguyendangthithuphuongy7ott@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	527722d1-c1d8-4371-8d05-27255ea29959
nguyendobaoquangb9iao@htqltd.vn	3f6c45d5-0af6-49d1-bfff-18ee90219e09	{"sub": "3f6c45d5-0af6-49d1-bfff-18ee90219e09", "email": "nguyendobaoquangb9iao@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	3f6c45d5-0af6-49d1-bfff-18ee90219e09
nguyenhohuuquangd73mk@htqltd.vn	4346719a-8af5-4d58-925b-918bfea097a5	{"sub": "4346719a-8af5-4d58-925b-918bfea097a5", "email": "nguyenhohuuquangd73mk@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	4346719a-8af5-4d58-925b-918bfea097a5
nguyenhokhacanhquanhqo2x@htqltd.vn	caf26390-b938-4714-932d-4065b88076fa	{"sub": "caf26390-b938-4714-932d-4065b88076fa", "email": "nguyenhokhacanhquanhqo2x@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	caf26390-b938-4714-932d-4065b88076fa
nguyenhosyquantz7a9@htqltd.vn	f6ba7b1d-619a-4e59-b7ac-77d396045470	{"sub": "f6ba7b1d-619a-4e59-b7ac-77d396045470", "email": "nguyenhosyquantz7a9@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	f6ba7b1d-619a-4e59-b7ac-77d396045470
nguyenphamvunhuquynhl48h4@htqltd.vn	10ef1208-5cf9-4b2c-aa79-5a4ee90996ac	{"sub": "10ef1208-5cf9-4b2c-aa79-5a4ee90996ac", "email": "nguyenphamvunhuquynhl48h4@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	10ef1208-5cf9-4b2c-aa79-5a4ee90996ac
nguyennguyenngoclanthanh62qs7@htqltd.vn	c64feb19-260e-4689-8119-11b01e6d4af2	{"sub": "c64feb19-260e-4689-8119-11b01e6d4af2", "email": "nguyennguyenngoclanthanh62qs7@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	c64feb19-260e-4689-8119-11b01e6d4af2
nguyenvohanhthaooxadp@htqltd.vn	701cc684-8fdf-4f70-bb1d-3116215074b8	{"sub": "701cc684-8fdf-4f70-bb1d-3116215074b8", "email": "nguyenvohanhthaooxadp@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	701cc684-8fdf-4f70-bb1d-3116215074b8
nguyentranhongthezjf5y@htqltd.vn	b6554e1c-2b00-486e-b02c-91b2d42bf02a	{"sub": "b6554e1c-2b00-486e-b02c-91b2d42bf02a", "email": "nguyentranhongthezjf5y@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	b6554e1c-2b00-486e-b02c-91b2d42bf02a
nguyenduongducthinh3hwkz@htqltd.vn	91d1ba8a-a2b4-44a5-b8d3-17a05b431b9a	{"sub": "91d1ba8a-a2b4-44a5-b8d3-17a05b431b9a", "email": "nguyenduongducthinh3hwkz@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	91d1ba8a-a2b4-44a5-b8d3-17a05b431b9a
nguyenphanngocthinhdehwc@htqltd.vn	3cdd5248-1fdd-4145-ba33-9248ef5eaf76	{"sub": "3cdd5248-1fdd-4145-ba33-9248ef5eaf76", "email": "nguyenphanngocthinhdehwc@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	3cdd5248-1fdd-4145-ba33-9248ef5eaf76
nguyenbuithilythumj5q8@htqltd.vn	232ad010-b123-40e2-846a-41cebf90111e	{"sub": "232ad010-b123-40e2-846a-41cebf90111e", "email": "nguyenbuithilythumj5q8@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	232ad010-b123-40e2-846a-41cebf90111e
nguyenhonguyenkhanhtrangbsr1f@htqltd.vn	ac793523-963a-4d25-bdef-4e8c30dc2736	{"sub": "ac793523-963a-4d25-bdef-4e8c30dc2736", "email": "nguyenhonguyenkhanhtrangbsr1f@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	ac793523-963a-4d25-bdef-4e8c30dc2736
nguyenhothithuytrangl6tmh@htqltd.vn	852227c7-2288-4397-a469-c2144d43943d	{"sub": "852227c7-2288-4397-a469-c2144d43943d", "email": "nguyenhothithuytrangl6tmh@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	852227c7-2288-4397-a469-c2144d43943d
nguyenlethithuytrang9h310@htqltd.vn	1672de6f-02b2-4c91-ae12-78c8309be791	{"sub": "1672de6f-02b2-4c91-ae12-78c8309be791", "email": "nguyenlethithuytrang9h310@htqltd.vn"}	email	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	1672de6f-02b2-4c91-ae12-78c8309be791
nguyennguyenthihuyentrangexrmk@htqltd.vn	ca4b8829-cf12-4b83-b83c-dc0b0dd8dcd9	{"sub": "ca4b8829-cf12-4b83-b83c-dc0b0dd8dcd9", "email": "nguyennguyenthihuyentrangexrmk@htqltd.vn"}	email	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	ca4b8829-cf12-4b83-b83c-dc0b0dd8dcd9
nguyennguyentranhuyentranglq4if@htqltd.vn	6469f68e-7a23-410a-a447-5efe4ae135f8	{"sub": "6469f68e-7a23-410a-a447-5efe4ae135f8", "email": "nguyennguyentranhuyentranglq4if@htqltd.vn"}	email	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	6469f68e-7a23-410a-a447-5efe4ae135f8
nguyennguyenquoctrongz50xx@htqltd.vn	57939031-c4a6-4774-9690-ae51ad84ff64	{"sub": "57939031-c4a6-4774-9690-ae51ad84ff64", "email": "nguyennguyenquoctrongz50xx@htqltd.vn"}	email	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	57939031-c4a6-4774-9690-ae51ad84ff64
nguyendoantuongvy03b62@htqltd.vn	30f178a9-8e39-401d-b560-b781c57c6fb3	{"sub": "30f178a9-8e39-401d-b560-b781c57c6fb3", "email": "nguyendoantuongvy03b62@htqltd.vn"}	email	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	30f178a9-8e39-401d-b560-b781c57c6fb3
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
3f3145e2-37da-447f-aed6-57d88a90ce27	2026-07-28 13:03:23.412606+00	2026-07-28 13:03:23.412606+00	password	5aa6976f-11d7-4ce7-9038-a943145e652d
d7bea47f-afa1-40eb-b355-2c70063c7453	2026-07-28 13:25:54.355046+00	2026-07-28 13:25:54.355046+00	password	e996da93-fcce-4543-8013-780d1eedff5f
5e89f060-2912-4f10-a21f-8fef3fa38689	2026-07-28 13:26:02.97801+00	2026-07-28 13:26:02.97801+00	password	45dc6b66-0864-4faa-bb42-f5e83ec889bd
ab3b31a4-cc3d-40a2-b214-16354ac10168	2026-07-28 13:50:16.982532+00	2026-07-28 13:50:16.982532+00	password	a99c9c62-e08d-4cbd-b5a8-d3b64515e1e4
75173ed1-979a-4a5d-82c4-f6fa22385b24	2026-07-28 14:02:11.386256+00	2026-07-28 14:02:11.386256+00	password	45e7bd51-425e-4bf4-8afc-a11d932b35c4
1381dc43-ae28-4800-aeff-cfdd97a484e8	2026-07-29 23:30:29.128831+00	2026-07-29 23:30:29.128831+00	password	21f848f5-3a69-49e7-9e96-c5384acd6381
4956085a-92fd-4661-b2ce-9dcc9b29de24	2026-08-03 01:39:45.505314+00	2026-08-03 01:39:45.505314+00	password	79ef6b38-9f5f-48b0-88e8-96e6bcbf9039
71cb2a42-ad50-4508-941b-103ab78eb846	2026-08-05 22:24:32.209437+00	2026-08-05 22:24:32.209437+00	password	ec460186-0051-4f3d-a7b2-4e8b32764428
be548200-7ab1-4215-8af8-c16ce9231ba6	2026-08-05 22:25:30.697454+00	2026-08-05 22:25:30.697454+00	password	0c308a0e-d622-4e96-9cb1-af434583a2d8
b84d3b9b-5da4-42f0-9624-7abf93d56b5c	2026-08-15 08:06:38.349876+00	2026-08-15 08:06:38.349876+00	password	9201a1bf-80b9-4ff8-b116-2bf01cda832e
9ae5938a-317a-4c5f-b5c5-2b43b8a6a1db	2026-08-16 07:01:36.72062+00	2026-08-16 07:01:36.72062+00	password	f427d5dd-1499-45cb-a6db-a0e45c4f6657
f9103081-8817-41d9-8b7c-440b1a2ea0ee	2026-08-17 22:17:54.569897+00	2026-08-17 22:17:54.569897+00	password	9cd2b792-159c-4f6a-a93e-a84b4f0ae549
e8c283cc-3701-4931-b8eb-5aa90fb1aad3	2026-08-19 14:23:12.891717+00	2026-08-19 14:23:12.891717+00	password	ccbd049b-37d9-48c8-8a3e-0cda197369dc
4e4814af-cf28-4eca-b307-26eaf9e16798	2026-08-19 14:23:42.061119+00	2026-08-19 14:23:42.061119+00	password	c715eb0e-1630-4a8e-af07-1700b6d2d036
f0df3575-e041-43f6-b3ca-a7d1428e6ed5	2026-08-19 14:24:45.045446+00	2026-08-19 14:24:45.045446+00	password	432efdfe-6094-4d15-a05e-f68b0a0cebab
89d0654a-9861-4340-8dc9-c949f190657b	2026-08-21 01:09:45.731104+00	2026-08-21 01:09:45.731104+00	password	719f6beb-a093-4f0d-ac0f-a19e4790dfb4
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	1	6jfwfvojcsoi	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-07-28 13:03:23.403668+00	2026-07-28 13:03:23.403668+00	\N	3f3145e2-37da-447f-aed6-57d88a90ce27
00000000-0000-0000-0000-000000000000	2	deq5u4mpptj7	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-07-28 13:25:54.333621+00	2026-07-28 13:25:54.333621+00	\N	d7bea47f-afa1-40eb-b355-2c70063c7453
00000000-0000-0000-0000-000000000000	3	6d3xkqnt3435	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-07-28 13:26:02.976285+00	2026-07-28 13:26:02.976285+00	\N	5e89f060-2912-4f10-a21f-8fef3fa38689
00000000-0000-0000-0000-000000000000	4	iaasvdhsifvj	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-07-28 13:50:16.960917+00	2026-07-28 13:50:16.960917+00	\N	ab3b31a4-cc3d-40a2-b214-16354ac10168
00000000-0000-0000-0000-000000000000	5	bd64g6m5flhj	b37f2829-c65a-48f9-a332-de9677f7732c	t	2026-07-28 14:02:11.379455+00	2026-07-28 15:01:28.745615+00	\N	75173ed1-979a-4a5d-82c4-f6fa22385b24
00000000-0000-0000-0000-000000000000	6	vglqobq34kek	b37f2829-c65a-48f9-a332-de9677f7732c	t	2026-07-28 15:01:28.761535+00	2026-07-29 23:08:44.77476+00	bd64g6m5flhj	75173ed1-979a-4a5d-82c4-f6fa22385b24
00000000-0000-0000-0000-000000000000	7	zcqubxpbl6bx	b37f2829-c65a-48f9-a332-de9677f7732c	f	2026-07-29 23:08:44.788286+00	2026-07-29 23:08:44.788286+00	vglqobq34kek	75173ed1-979a-4a5d-82c4-f6fa22385b24
00000000-0000-0000-0000-000000000000	9	eujta6lxodvr	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-03 01:39:45.492351+00	2026-08-03 02:38:17.125061+00	\N	4956085a-92fd-4661-b2ce-9dcc9b29de24
00000000-0000-0000-0000-000000000000	10	6h2bop2anz3m	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-08-03 02:38:17.142089+00	2026-08-03 02:38:17.142089+00	eujta6lxodvr	4956085a-92fd-4661-b2ce-9dcc9b29de24
00000000-0000-0000-0000-000000000000	8	d3dfxl24u4sg	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-07-29 23:30:29.11472+00	2026-08-05 22:23:40.331901+00	\N	1381dc43-ae28-4800-aeff-cfdd97a484e8
00000000-0000-0000-0000-000000000000	11	srej2umwahub	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-08-05 22:23:40.34612+00	2026-08-05 22:23:40.34612+00	d3dfxl24u4sg	1381dc43-ae28-4800-aeff-cfdd97a484e8
00000000-0000-0000-0000-000000000000	12	typ7c5amzmwc	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-05 22:24:32.198517+00	2026-08-05 23:23:45.909854+00	\N	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	13	ck5em4qwj6hf	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-05 22:25:30.687212+00	2026-08-05 23:24:45.968078+00	\N	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	14	cc7dfusvw5xg	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-05 23:23:45.918353+00	2026-08-06 00:22:45.866601+00	typ7c5amzmwc	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	15	ftikamgb6y2l	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-05 23:24:45.98003+00	2026-08-06 00:23:45.739053+00	ck5em4qwj6hf	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	16	bhvya52cgthy	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 00:22:45.876595+00	2026-08-06 01:21:45.868631+00	cc7dfusvw5xg	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	17	fasfi2zzqjbm	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 00:23:45.739499+00	2026-08-06 01:22:18.69074+00	ftikamgb6y2l	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	18	6o6o3wycrsqk	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 01:21:45.876024+00	2026-08-06 02:20:45.942798+00	bhvya52cgthy	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	19	thf4ls23hd5y	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 01:22:18.701587+00	2026-08-06 02:21:45.73647+00	fasfi2zzqjbm	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	20	hndb5bcbbhsh	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 02:20:45.971663+00	2026-08-06 06:58:45.593548+00	6o6o3wycrsqk	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	21	ru5naucxxj67	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 02:21:45.742554+00	2026-08-06 06:58:45.59369+00	thf4ls23hd5y	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	22	snqil4oyeipm	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 06:58:45.617479+00	2026-08-06 07:57:42.364204+00	ru5naucxxj67	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	24	6qyxhlqmuu7l	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 07:57:42.392609+00	2026-08-06 12:42:12.298574+00	snqil4oyeipm	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	25	6logtbxfwnb6	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-08-06 12:42:12.320933+00	2026-08-06 12:42:12.320933+00	6qyxhlqmuu7l	be548200-7ab1-4215-8af8-c16ce9231ba6
00000000-0000-0000-0000-000000000000	23	g43rmnaf3fmq	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-06 06:58:45.617479+00	2026-08-11 13:05:57.871962+00	hndb5bcbbhsh	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	26	q4y4ha3piywe	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-11 13:05:57.883751+00	2026-08-14 11:36:21.8925+00	g43rmnaf3fmq	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	27	cxhl4n7m7ljh	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 11:36:21.907628+00	2026-08-14 12:34:58.555662+00	q4y4ha3piywe	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	28	k2733m7euytn	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 12:34:58.58705+00	2026-08-14 13:33:58.162954+00	cxhl4n7m7ljh	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	29	ajflcjwmi3a6	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 13:33:58.184043+00	2026-08-14 14:32:58.128913+00	k2733m7euytn	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	30	xpawsceyqvee	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 14:32:58.151787+00	2026-08-14 15:31:57.964219+00	ajflcjwmi3a6	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	31	xb77ikhtmacr	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 15:31:57.97976+00	2026-08-14 16:30:57.932421+00	xpawsceyqvee	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	32	kabqigoadghx	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 16:30:57.946453+00	2026-08-14 17:29:58.026612+00	xb77ikhtmacr	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	33	7hdyef2zrkbg	877693ae-8c6c-45bf-960c-12b1faae2c56	t	2026-08-14 17:29:58.050618+00	2026-08-14 18:28:57.811888+00	kabqigoadghx	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	34	x5ly7eyof324	877693ae-8c6c-45bf-960c-12b1faae2c56	f	2026-08-14 18:28:57.836906+00	2026-08-14 18:28:57.836906+00	7hdyef2zrkbg	71cb2a42-ad50-4508-941b-103ab78eb846
00000000-0000-0000-0000-000000000000	35	litfib4terpk	7538ae71-cb90-4191-8bd3-349b2e92dc14	t	2026-08-15 08:06:38.340373+00	2026-08-15 09:05:52.22693+00	\N	b84d3b9b-5da4-42f0-9624-7abf93d56b5c
00000000-0000-0000-0000-000000000000	36	3rapt4v575o6	7538ae71-cb90-4191-8bd3-349b2e92dc14	t	2026-08-15 09:05:52.243061+00	2026-08-15 10:04:52.27502+00	litfib4terpk	b84d3b9b-5da4-42f0-9624-7abf93d56b5c
00000000-0000-0000-0000-000000000000	37	xdi4rauavydj	7538ae71-cb90-4191-8bd3-349b2e92dc14	f	2026-08-15 10:04:52.294189+00	2026-08-15 10:04:52.294189+00	3rapt4v575o6	b84d3b9b-5da4-42f0-9624-7abf93d56b5c
00000000-0000-0000-0000-000000000000	38	xwugmpgodue2	7538ae71-cb90-4191-8bd3-349b2e92dc14	f	2026-08-16 07:01:36.693366+00	2026-08-16 07:01:36.693366+00	\N	9ae5938a-317a-4c5f-b5c5-2b43b8a6a1db
00000000-0000-0000-0000-000000000000	39	qwscxyuzqmhx	7538ae71-cb90-4191-8bd3-349b2e92dc14	t	2026-08-17 22:17:54.548845+00	2026-08-17 23:16:26.567154+00	\N	f9103081-8817-41d9-8b7c-440b1a2ea0ee
00000000-0000-0000-0000-000000000000	40	juxtyaff4fdt	7538ae71-cb90-4191-8bd3-349b2e92dc14	f	2026-08-17 23:16:26.580079+00	2026-08-17 23:16:26.580079+00	qwscxyuzqmhx	f9103081-8817-41d9-8b7c-440b1a2ea0ee
00000000-0000-0000-0000-000000000000	41	7xlul23ju3vg	7538ae71-cb90-4191-8bd3-349b2e92dc14	f	2026-08-19 14:23:12.85849+00	2026-08-19 14:23:12.85849+00	\N	e8c283cc-3701-4931-b8eb-5aa90fb1aad3
00000000-0000-0000-0000-000000000000	42	du63cimb7gdg	7538ae71-cb90-4191-8bd3-349b2e92dc14	f	2026-08-19 14:23:42.059354+00	2026-08-19 14:23:42.059354+00	\N	4e4814af-cf28-4eca-b307-26eaf9e16798
00000000-0000-0000-0000-000000000000	43	w5dqxqiz57cw	91d1ba8a-a2b4-44a5-b8d3-17a05b431b9a	f	2026-08-19 14:24:45.040484+00	2026-08-19 14:24:45.040484+00	\N	f0df3575-e041-43f6-b3ca-a7d1428e6ed5
00000000-0000-0000-0000-000000000000	44	xkfvx5gkhqtp	7538ae71-cb90-4191-8bd3-349b2e92dc14	f	2026-08-21 01:09:45.710011+00	2026-08-21 01:09:45.710011+00	\N	89d0654a-9861-4340-8dc9-c949f190657b
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
3f3145e2-37da-447f-aed6-57d88a90ce27	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-07-28 13:03:23.396678+00	2026-07-28 13:03:23.396678+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
d7bea47f-afa1-40eb-b355-2c70063c7453	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-07-28 13:25:54.306289+00	2026-07-28 13:25:54.306289+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
5e89f060-2912-4f10-a21f-8fef3fa38689	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-07-28 13:26:02.973902+00	2026-07-28 13:26:02.973902+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
ab3b31a4-cc3d-40a2-b214-16354ac10168	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-07-28 13:50:16.94511+00	2026-07-28 13:50:16.94511+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
75173ed1-979a-4a5d-82c4-f6fa22385b24	b37f2829-c65a-48f9-a332-de9677f7732c	2026-07-28 14:02:11.37461+00	2026-07-29 23:08:44.817618+00	\N	aal1	\N	2026-07-29 23:08:44.817502	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
4956085a-92fd-4661-b2ce-9dcc9b29de24	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-08-03 01:39:45.467857+00	2026-08-03 02:38:17.173677+00	\N	aal1	\N	2026-08-03 02:38:17.173327	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0	171.251.238.50	\N	\N	\N	\N	\N
1381dc43-ae28-4800-aeff-cfdd97a484e8	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-07-29 23:30:29.09156+00	2026-08-05 22:23:40.373868+00	\N	aal1	\N	2026-08-05 22:23:40.37375	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
b84d3b9b-5da4-42f0-9624-7abf93d56b5c	7538ae71-cb90-4191-8bd3-349b2e92dc14	2026-08-15 08:06:38.329015+00	2026-08-15 10:04:52.329855+00	\N	aal1	\N	2026-08-15 10:04:52.329691	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
9ae5938a-317a-4c5f-b5c5-2b43b8a6a1db	7538ae71-cb90-4191-8bd3-349b2e92dc14	2026-08-16 07:01:36.674306+00	2026-08-16 07:01:36.674306+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
f9103081-8817-41d9-8b7c-440b1a2ea0ee	7538ae71-cb90-4191-8bd3-349b2e92dc14	2026-08-17 22:17:54.530776+00	2026-08-17 23:16:26.604081+00	\N	aal1	\N	2026-08-17 23:16:26.60396	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
e8c283cc-3701-4931-b8eb-5aa90fb1aad3	7538ae71-cb90-4191-8bd3-349b2e92dc14	2026-08-19 14:23:12.823131+00	2026-08-19 14:23:12.823131+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
4e4814af-cf28-4eca-b307-26eaf9e16798	7538ae71-cb90-4191-8bd3-349b2e92dc14	2026-08-19 14:23:42.05628+00	2026-08-19 14:23:42.05628+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
f0df3575-e041-43f6-b3ca-a7d1428e6ed5	91d1ba8a-a2b4-44a5-b8d3-17a05b431b9a	2026-08-19 14:24:45.035876+00	2026-08-19 14:24:45.035876+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
89d0654a-9861-4340-8dc9-c949f190657b	7538ae71-cb90-4191-8bd3-349b2e92dc14	2026-08-21 01:09:45.6866+00	2026-08-21 01:09:45.6866+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.52	\N	\N	\N	\N	\N
be548200-7ab1-4215-8af8-c16ce9231ba6	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-08-05 22:25:30.660276+00	2026-08-06 12:42:12.354036+00	\N	aal1	\N	2026-08-06 12:42:12.35328	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
71cb2a42-ad50-4508-941b-103ab78eb846	877693ae-8c6c-45bf-960c-12b1faae2c56	2026-08-05 22:24:32.162724+00	2026-08-14 18:28:57.869171+00	\N	aal1	\N	2026-08-14 18:28:57.869049	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	7538ae71-cb90-4191-8bd3-349b2e92dc14	authenticated	authenticated	admin@htqltd.vn	$2a$10$3vMdAtZIpRCGbbJeYBuh8uf5ShESvTov0guPgg6P5DCx0W8UTEbI2	2026-08-15 08:06:38.318524+00	\N		\N		\N			\N	2026-08-21 01:09:45.685369+00	{"provider": "email", "providers": ["email"]}	{"role": "Admin", "fullname": "Quản trị", "username": "Admin", "chidoan_id": null, "doanvien_id": null}	\N	2026-08-15 08:06:38.271614+00	2026-08-21 01:09:45.724885+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b37f2829-c65a-48f9-a332-de9677f7732c	authenticated	authenticated	nguyenbuingocdat@schms4o1j90uxhk.com	$2a$10$vzipLlE6S4ZbEhn8KAGCz.7RPbciV8WHZ9oSc21lbZELT.TCgGA9C	2026-07-28 14:02:11.365503+00	\N		\N		\N			\N	2026-07-28 14:02:11.374475+00	{"provider": "email", "providers": ["email"]}	{"sub": "b37f2829-c65a-48f9-a332-de9677f7732c", "email": "nguyenbuingocdat@schms4o1j90uxhk.com", "email_verified": true, "phone_verified": false}	\N	2026-07-28 14:02:11.332332+00	2026-07-29 23:08:44.798686+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	877693ae-8c6c-45bf-960c-12b1faae2c56	authenticated	authenticated	admin@schms4o1j90uxhk.com	$2a$10$O6/XqaeM.BZTO2Yjc7cM5OKwUk8C6XDnv3aDjZP0LowoxLtoVK4fi	2026-07-28 13:03:23.385321+00	\N		\N		\N			\N	2026-08-05 22:25:30.659283+00	{"provider": "email", "providers": ["email"]}	{"sub": "877693ae-8c6c-45bf-960c-12b1faae2c56", "email": "admin@schms4o1j90uxhk.com", "email_verified": true, "phone_verified": false}	\N	2026-07-28 13:03:23.344233+00	2026-08-14 18:28:57.846537+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	571016d6-2fad-430b-aefb-777f161bd79a	authenticated	authenticated	nguyenphamduonganha930g@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Dương Anh", "username": "nguyenphamduonganha930g", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "f035ea67-de6a-412a-8db0-0a1aa3fb6877"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6d408d6d-8d8c-4aec-a5a1-5ab03975889a	authenticated	authenticated	nguyenphamvanbe8sog1@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Văn Bé", "username": "nguyenphamvanbe8sog1", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "596a1118-dde3-4bde-bb36-5cd64ea23f2c"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3b148c8a-7cd1-4481-b3de-d31363b5eb1b	authenticated	authenticated	nguyenluongthanhbinh3teye@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lương Thanh Bình", "username": "nguyenluongthanhbinh3teye", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "0cb70593-3e58-4247-a825-673ffd97c4d9"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	be9acf02-5690-4daa-90f6-61b4ea1e806e	authenticated	authenticated	nguyenbuingocdat8gnrg@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Bùi Ngọc Đạt", "username": "nguyenbuingocdat8gnrg", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "8d1ead77-ab5e-455f-bc46-311a217ed7a1"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cec65c10-9bd9-45df-9d5c-5b35dfcf1006	authenticated	authenticated	nguyentrankhanhha13u6r@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn TRẦN KHÁNH HÀ", "username": "nguyentrankhanhha13u6r", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "89787c05-61a5-4423-9207-6125c6e17a07"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c99cfa85-9762-4bc1-a8f7-0723ab12915a	authenticated	authenticated	nguyennguyenconghau1tdht@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Công Hậu", "username": "nguyennguyenconghau1tdht", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "a2cbd851-8587-4a84-ae5e-5c2dd4bb039d"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a08cd0f4-4c6d-4d17-9713-c1ed49f1c104	authenticated	authenticated	nguyennguyenduchieua2mrs@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Đức Hiếu", "username": "nguyennguyenduchieua2mrs", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "d3bed503-a490-4d45-998f-dab5e6bb499c"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	639d8d64-f28f-4625-9f09-7eee1c053421	authenticated	authenticated	nguyennguyenvanhieuwrgtd@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Văn Hiếu", "username": "nguyennguyenvanhieuwrgtd", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "ba5c0329-2c94-4156-a039-42a2847c7414"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f11d8f73-bce0-4132-a33c-79e9449c8512	authenticated	authenticated	nguyenlethithuyhoaivi8db@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Thị Thúy Hoài", "username": "nguyenlethithuyhoaivi8db", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "64c9a6c6-318b-43b9-9154-ba30c0c8d809"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	dd996984-dc67-43d0-b2f9-7464dddcff6f	authenticated	authenticated	nguyendinhngockhanhhuyen9b58d@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đinh Ngọc Khánh Huyền", "username": "nguyendinhngockhanhhuyen9b58d", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "0a848333-18cb-4e16-9f34-89b7222ac825"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bf42d522-5568-4e42-b5c1-13b67d01957a	authenticated	authenticated	nguyenphamquochungvvlvo@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Quốc Hưng", "username": "nguyenphamquochungvvlvo", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "1023b8d0-1c96-40a3-89a9-892e48225944"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4153fa98-e8e8-44bf-a96a-caba5a82045d	authenticated	authenticated	nguyendaovietkhanhtr1t8@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đào Viết Khánh", "username": "nguyendaovietkhanhtr1t8", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "73446302-f027-4c4d-ae73-4489b88145cf"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e3753456-573b-44da-ba5e-e1332a9e366a	authenticated	authenticated	nguyennguyenquangkien45rpt@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Quang Kiên", "username": "nguyennguyenquangkien45rpt", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "6daec1b8-be20-4c18-b5ca-f6dc58588389"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b8da3dd3-5792-4861-b7c4-f9be27e75cb9	authenticated	authenticated	nguyennguyenkhanhlinhi8sub@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Khánh Linh", "username": "nguyennguyenkhanhlinhi8sub", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "72167279-74bc-4e55-b82c-14224394cdaf"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d6575387-b6c6-485e-b9f9-73ef03d070bb	authenticated	authenticated	nguyennguyenphilongq79ue@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Phi Long", "username": "nguyennguyenphilongq79ue", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "ed3384d3-cace-43f1-b23b-9ec5b210948a"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	249781d9-5a7d-46fb-8775-45a1cfde70c7	authenticated	authenticated	nguyentranducluong9x5gv@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Trần Đức Lương", "username": "nguyentranducluong9x5gv", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "9f6fdd3e-2639-4ed4-bae1-d412d108adb8"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	058679cf-8e32-4d72-ad03-271754722ce7	authenticated	authenticated	nguyenhothikhanhlyl54h1@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Thị Khánh Ly", "username": "nguyenhothikhanhlyl54h1", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "dcc0a96a-79a1-4706-81e4-80304bab6771"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5fbbab1e-ef9a-48ca-92c1-da568e5d06c9	authenticated	authenticated	nguyennguyenhoangbaominhgqeu6@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Hoàng Bảo Minh", "username": "nguyennguyenhoangbaominhgqeu6", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "19af9fa6-18b8-4ebe-bd23-7a395d9dcddd"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6fe2212a-a4fc-4249-832a-560c7e7c0690	authenticated	authenticated	nguyenhothungaq2o4x@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Thu Nga", "username": "nguyenhothungaq2o4x", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "fa49e870-21cd-4dcd-91a2-169b780df5d3"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3de1a592-b252-4f60-a587-30bb78d216c7	authenticated	authenticated	nguyentrinhthihangngam4gxp@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.138493+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Trịnh Thị Hằng Nga", "username": "nguyentrinhthihangngam4gxp", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "e73f99c3-c8a5-4943-8f72-3ae965b84b07"}	\N	2026-08-19 14:24:09.138493+00	2026-08-19 14:24:09.138493+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	01ea9826-d1bf-415d-9755-865e99819af6	authenticated	authenticated	nguyennguyenlucngan0e0uw@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Lục Ngạn", "username": "nguyennguyenlucngan0e0uw", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "2feacb20-f3c0-49e5-9e57-37e2d8d1fb24"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	72c338a9-df22-4f28-9593-3307a2746b28	authenticated	authenticated	nguyenlehoangmyngocosom0@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Hoàng Mỹ Ngọc", "username": "nguyenlehoangmyngocosom0", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "fd7f0142-44d7-4ca9-8095-08bfdfeaec02"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	102c96c5-21aa-4aec-82c5-c25267ba2f0b	authenticated	authenticated	nguyenlethibaongocmquay@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Thị Bảo Ngọc", "username": "nguyenlethibaongocmquay", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "d2e884dd-5353-4c35-a596-dd70a045c071"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6c8609fd-dd6e-4c5e-90a3-82fa5adb59ea	authenticated	authenticated	nguyencaoanhnhanwfjao@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Cao Anh Nhân", "username": "nguyencaoanhnhanwfjao", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "0990653e-3ad8-4f20-b390-ef739c0b0b09"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f80ab2d3-09a6-4241-a70b-e015fa0e0e2a	authenticated	authenticated	nguyenlevothanhnhatm5pc8@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Võ Thanh Nhật", "username": "nguyenlevothanhnhatm5pc8", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "59700d22-2bc0-4a5d-bae6-4af4cf58146a"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	527722d1-c1d8-4371-8d05-27255ea29959	authenticated	authenticated	nguyendangthithuphuongy7ott@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đặng Thị Thu Phương", "username": "nguyendangthithuphuongy7ott", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "b62342dd-07bc-4e9c-aad2-f1803450734f"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3f6c45d5-0af6-49d1-bfff-18ee90219e09	authenticated	authenticated	nguyendobaoquangb9iao@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đỗ Bảo Quang", "username": "nguyendobaoquangb9iao", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "d09d798a-4051-499a-a226-48f7e920cdc2"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4346719a-8af5-4d58-925b-918bfea097a5	authenticated	authenticated	nguyenhohuuquangd73mk@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Hữu Quang", "username": "nguyenhohuuquangd73mk", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "f1c26ce8-50b2-491e-bcfa-a87610902994"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	caf26390-b938-4714-932d-4065b88076fa	authenticated	authenticated	nguyenhokhacanhquanhqo2x@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hô Khắc Anh Quân", "username": "nguyenhokhacanhquanhqo2x", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "5584edc9-f202-4b53-be04-0a850dcff28e"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f6ba7b1d-619a-4e59-b7ac-77d396045470	authenticated	authenticated	nguyenhosyquantz7a9@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Sỹ Quân", "username": "nguyenhosyquantz7a9", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "8c762b34-a838-4009-8f3c-0034df09b5b5"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	10ef1208-5cf9-4b2c-aa79-5a4ee90996ac	authenticated	authenticated	nguyenphamvunhuquynhl48h4@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Vũ Như Quỳnh", "username": "nguyenphamvunhuquynhl48h4", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "ad486648-57ab-40db-8c85-94150b12543b"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c64feb19-260e-4689-8119-11b01e6d4af2	authenticated	authenticated	nguyennguyenngoclanthanh62qs7@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Ngọc Lan Thanh", "username": "nguyennguyenngoclanthanh62qs7", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "a809ced4-8ba7-4115-8d23-e99711cc74f9"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	701cc684-8fdf-4f70-bb1d-3116215074b8	authenticated	authenticated	nguyenvohanhthaooxadp@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Võ Hạnh Thảo", "username": "nguyenvohanhthaooxadp", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "d9a7b926-0a8c-4f47-b619-6433096d9f58"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b6554e1c-2b00-486e-b02c-91b2d42bf02a	authenticated	authenticated	nguyentranhongthezjf5y@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Trần Hồng Thế", "username": "nguyentranhongthezjf5y", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "53f81aec-18c5-4c23-984e-cc009ba9b302"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3cdd5248-1fdd-4145-ba33-9248ef5eaf76	authenticated	authenticated	nguyenphanngocthinhdehwc@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phan Ngọc Thịnh", "username": "nguyenphanngocthinhdehwc", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "64dd0e90-5341-4595-8a5e-57ecb1f570ac"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	232ad010-b123-40e2-846a-41cebf90111e	authenticated	authenticated	nguyenbuithilythumj5q8@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Bùi Thị Lý Thu", "username": "nguyenbuithilythumj5q8", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "2cd94e92-31ba-4139-90c6-b448721d0e5a"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ac793523-963a-4d25-bdef-4e8c30dc2736	authenticated	authenticated	nguyenhonguyenkhanhtrangbsr1f@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Nguyễn Khánh Trang", "username": "nguyenhonguyenkhanhtrangbsr1f", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "28b3d6b7-b037-4102-98b4-ee7519cb2938"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	852227c7-2288-4397-a469-c2144d43943d	authenticated	authenticated	nguyenhothithuytrangl6tmh@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Thị Thùy Trang", "username": "nguyenhothithuytrangl6tmh", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "14d0fdc8-e161-484a-8120-92d269df733c"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1672de6f-02b2-4c91-ae12-78c8309be791	authenticated	authenticated	nguyenlethithuytrang9h310@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Thị Thùy Trang", "username": "nguyenlethithuytrang9h310", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "eff799ee-7290-48cf-94b6-72491e9031bd"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:09.313+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ca4b8829-cf12-4b83-b83c-dc0b0dd8dcd9	authenticated	authenticated	nguyennguyenthihuyentrangexrmk@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.451721+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Thị Huyền Trang", "username": "nguyennguyenthihuyentrangexrmk", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "b7385976-b56a-4495-88cf-7f4ae9f53cce"}	\N	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6469f68e-7a23-410a-a447-5efe4ae135f8	authenticated	authenticated	nguyennguyentranhuyentranglq4if@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.451721+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Trần Huyền Trang", "username": "nguyennguyentranhuyentranglq4if", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "9622ebdc-c7ce-4c27-ae8f-010b7f0f5c30"}	\N	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	57939031-c4a6-4774-9690-ae51ad84ff64	authenticated	authenticated	nguyennguyenquoctrongz50xx@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.451721+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Quốc Trọng", "username": "nguyennguyenquoctrongz50xx", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "c00ef7bc-85d4-47e8-adc9-932a01533d8f"}	\N	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	30f178a9-8e39-401d-b560-b781c57c6fb3	authenticated	authenticated	nguyendoantuongvy03b62@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.451721+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đoàn Tường Vy", "username": "nguyendoantuongvy03b62", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "43ed91ed-89eb-4c51-b2aa-86801215b5da"}	\N	2026-08-19 14:24:09.451721+00	2026-08-19 14:24:09.451721+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	91d1ba8a-a2b4-44a5-b8d3-17a05b431b9a	authenticated	authenticated	nguyenduongducthinh3hwkz@htqltd.vn	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	2026-08-19 14:24:09.313+00	\N		\N		\N			\N	2026-08-19 14:24:45.031734+00	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Dương Đức Thịnh", "username": "nguyenduongducthinh3hwkz", "chidoan_id": "6aea5656-7af7-491a-9376-19358f3f1893", "doanvien_id": "4b6b37f6-5360-4fdf-aca7-fc5782fedcc9"}	\N	2026-08-19 14:24:09.313+00	2026-08-19 14:24:45.04414+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: cauhinh_tieuchi_xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cauhinh_tieuchi_xet_thidua" ("id", "namhoc_id", "hoc_ky", "ten_tieuchi_1", "sudung_1", "kieudulieu_1", "ten_tieuchi_2", "sudung_2", "kieudulieu_2", "ten_tieuchi_3", "sudung_3", "kieudulieu_3", "ten_tieuchi_4", "sudung_4", "kieudulieu_4", "ten_tieuchi_5", "sudung_5", "kieudulieu_5", "ten_tieuchi_6", "sudung_6", "kieudulieu_6", "ten_tieuchi_7", "sudung_7", "kieudulieu_7", "ten_tieuchi_8", "sudung_8", "kieudulieu_8", "ten_tieuchi_9", "sudung_9", "kieudulieu_9", "ten_tieuchi_10", "sudung_10", "kieudulieu_10", "created_at", "updated_at", "ghi_chu", "giai_thich", "trang_thai") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "diachi", "chidoan_id", "createdat", "sothedoan", "phuongtien", "thongtinphuongtien") FROM stdin;
f035ea67-de6a-412a-8db0-0a1aa3fb6877	Nguyễn Phạm Dương Anh	20/10/2026	Nam	Kinh	\N	t	\N	17/01/2026	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
596a1118-dde3-4bde-bb36-5cd64ea23f2c	Nguyễn Phạm Văn Bé	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
0cb70593-3e58-4247-a825-673ffd97c4d9	Nguyễn Lương Thanh Bình	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
8d1ead77-ab5e-455f-bc46-311a217ed7a1	Nguyễn Bùi Ngọc Đạt	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
89787c05-61a5-4423-9207-6125c6e17a07	Nguyễn TRẦN KHÁNH HÀ	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
a2cbd851-8587-4a84-ae5e-5c2dd4bb039d	Nguyễn Nguyễn Công Hậu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
d3bed503-a490-4d45-998f-dab5e6bb499c	Nguyễn Nguyễn Đức Hiếu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
ba5c0329-2c94-4156-a039-42a2847c7414	Nguyễn Nguyễn Văn Hiếu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
64c9a6c6-318b-43b9-9154-ba30c0c8d809	Nguyễn Lê Thị Thúy Hoài	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
0a848333-18cb-4e16-9f34-89b7222ac825	Nguyễn Đinh Ngọc Khánh Huyền	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
1023b8d0-1c96-40a3-89a9-892e48225944	Nguyễn Phạm Quốc Hưng	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
73446302-f027-4c4d-ae73-4489b88145cf	Nguyễn Đào Viết Khánh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
6daec1b8-be20-4c18-b5ca-f6dc58588389	Nguyễn Nguyễn Quang Kiên	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
72167279-74bc-4e55-b82c-14224394cdaf	Nguyễn Nguyễn Khánh Linh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
ed3384d3-cace-43f1-b23b-9ec5b210948a	Nguyễn Nguyễn Phi Long	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
9f6fdd3e-2639-4ed4-bae1-d412d108adb8	Nguyễn Trần Đức Lương	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
dcc0a96a-79a1-4706-81e4-80304bab6771	Nguyễn Hồ Thị Khánh Ly	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
19af9fa6-18b8-4ebe-bd23-7a395d9dcddd	Nguyễn Nguyễn Hoàng Bảo Minh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
fa49e870-21cd-4dcd-91a2-169b780df5d3	Nguyễn Hồ Thu Nga	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
e73f99c3-c8a5-4943-8f72-3ae965b84b07	Nguyễn Trịnh Thị Hằng Nga	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
2feacb20-f3c0-49e5-9e57-37e2d8d1fb24	Nguyễn Nguyễn Lục Ngạn	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
fd7f0142-44d7-4ca9-8095-08bfdfeaec02	Nguyễn Lê Hoàng Mỹ Ngọc	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
d2e884dd-5353-4c35-a596-dd70a045c071	Nguyễn Lê Thị Bảo Ngọc	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
0990653e-3ad8-4f20-b390-ef739c0b0b09	Nguyễn Cao Anh Nhân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
59700d22-2bc0-4a5d-bae6-4af4cf58146a	Nguyễn Lê Võ Thanh Nhật	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
b62342dd-07bc-4e9c-aad2-f1803450734f	Nguyễn Đặng Thị Thu Phương	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
d09d798a-4051-499a-a226-48f7e920cdc2	Nguyễn Đỗ Bảo Quang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
f1c26ce8-50b2-491e-bcfa-a87610902994	Nguyễn Hồ Hữu Quang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
5584edc9-f202-4b53-be04-0a850dcff28e	Nguyễn Hô Khắc Anh Quân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
8c762b34-a838-4009-8f3c-0034df09b5b5	Nguyễn Hồ Sỹ Quân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
ad486648-57ab-40db-8c85-94150b12543b	Nguyễn Phạm Vũ Như Quỳnh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
a809ced4-8ba7-4115-8d23-e99711cc74f9	Nguyễn Nguyễn Ngọc Lan Thanh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
d9a7b926-0a8c-4f47-b619-6433096d9f58	Nguyễn Võ Hạnh Thảo	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
53f81aec-18c5-4c23-984e-cc009ba9b302	Nguyễn Trần Hồng Thế	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
4b6b37f6-5360-4fdf-aca7-fc5782fedcc9	Nguyễn Dương Đức Thịnh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
64dd0e90-5341-4595-8a5e-57ecb1f570ac	Nguyễn Phan Ngọc Thịnh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
2cd94e92-31ba-4139-90c6-b448721d0e5a	Nguyễn Bùi Thị Lý Thu	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
28b3d6b7-b037-4102-98b4-ee7519cb2938	Nguyễn Hồ Nguyễn Khánh Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
14d0fdc8-e161-484a-8120-92d269df733c	Nguyễn Hồ Thị Thùy Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
eff799ee-7290-48cf-94b6-72491e9031bd	Nguyễn Lê Thị Thùy Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
b7385976-b56a-4495-88cf-7f4ae9f53cce	Nguyễn Nguyễn Thị Huyền Trang	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
9622ebdc-c7ce-4c27-ae8f-010b7f0f5c30	Nguyễn Nguyễn Trần Huyền Trang	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
c00ef7bc-85d4-47e8-adc9-932a01533d8f	Nguyễn Nguyễn Quốc Trọng	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
43ed91ed-89eb-4c51-b2aa-86801215b5da	Nguyễn Đoàn Tường Vy	20/10/2026	Nam	Kinh	\N	t	\N	24/03/2025	\N	\N	2026-07-28 13:39:30.390141+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	Xã ABC - tỉnh ABC - Việt Nam	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 13:39:30.390141+00	\N	\N	\N
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
f34f8feb-2535-4623-b7b1-b790e6335938	441	2026-07-28 12:52:32.331275+00	2026-07-28 12:52:32.331275+00	2026-08-21 04:36:24.760002+00
\.


--
-- Data for Name: gio_hoc_tap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."gio_hoc_tap" ("id", "namhoc_id", "chidoan_id", "tuan_id", "so_tot", "so_kha", "so_tb", "so_yeu", "diem_tot_cauhinh", "diem_kha_cauhinh", "diem_tb_cauhinh", "diem_yeu_cauhinh", "diem_tb_hoc_tap", "updated_at", "hocky") FROM stdin;
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
default	hohuuthe/gialaithpttranphu	main	supabase-backup.yml	supabase-restore.yml	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	2026-08-15 08:08:00.515+00	Admin	2026-07-29 23:31:44.388985+00	2026-08-15 08:08:00.095469+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "islocked", "updatedat", "createdat", "isdefault") FROM stdin;
0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-2027	f	2026-07-28 13:04:11.003734+00	2026-07-28 13:04:11.003734+00	f
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
cb67b5a0-3172-42de-8671-8781cb7742eb	HK1	1	6aea5656-7af7-491a-9376-19358f3f1893	14adc0ee-fdc9-4301-9e01-34fb739b8c16	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
14e41c7a-7657-4c53-ad0a-923ccfe1b817	HK1	1	14adc0ee-fdc9-4301-9e01-34fb739b8c16	acc925e5-6206-4895-acdb-7e38a4e2e65b	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
dd5c1ce8-32c8-44bf-88db-2769b6ae2b98	HK1	1	acc925e5-6206-4895-acdb-7e38a4e2e65b	410a2919-b354-4c7e-996a-1dcbcd625bb2	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
dce29e42-3aa3-446a-8c33-e96b92ddd1d3	HK1	1	410a2919-b354-4c7e-996a-1dcbcd625bb2	466bc1a7-c545-4aa6-ae55-b89d5e19eec8	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
e9224c7b-a413-410a-bd63-de973aa2cf28	HK1	1	466bc1a7-c545-4aa6-ae55-b89d5e19eec8	890093ed-9c7f-4c0a-98bb-20f365a970c7	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
a13fa5e7-ed63-41e6-8101-2ceb188a7cff	HK1	1	890093ed-9c7f-4c0a-98bb-20f365a970c7	bb7f5708-2666-4eb0-83fd-f01d29d81bb8	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
7bd88151-e600-48b4-b96c-29bf374c6266	HK1	1	bb7f5708-2666-4eb0-83fd-f01d29d81bb8	b1185b4a-af94-4eca-ba55-9ee6189fd2cb	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
22c9e40b-164f-49ce-9db0-684847677728	HK1	1	b1185b4a-af94-4eca-ba55-9ee6189fd2cb	760beb12-74e2-4ac2-be1c-97562e9fc1c1	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
e4e5e02b-92b2-4c70-bba2-6019b868cf10	HK1	1	760beb12-74e2-4ac2-be1c-97562e9fc1c1	f54b64b0-4a30-4be9-991a-620af6966771	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
289f89c4-6d07-469a-a117-65c02ff23018	HK1	1	f54b64b0-4a30-4be9-991a-620af6966771	cdab1277-35b9-41d6-ac2a-9e00c2b46827	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
7da597b0-3aa9-4d60-b907-fd79500f19fb	HK1	1	cdab1277-35b9-41d6-ac2a-9e00c2b46827	4ba0c710-1a9e-48ab-89f5-6764e9bbc78d	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
aff44d1b-c58f-4965-addf-ce53d8972d8c	HK1	1	4ba0c710-1a9e-48ab-89f5-6764e9bbc78d	c9481035-336f-4435-9442-871952183193	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
0abe10fe-9100-43b5-a37d-d36b1ea76c97	HK1	1	c9481035-336f-4435-9442-871952183193	c9a78ea0-851a-4eab-8599-19f1f216b6f6	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
dcc7c15f-5b4d-4949-a25b-29bc685e8664	HK1	1	c9a78ea0-851a-4eab-8599-19f1f216b6f6	ecb33362-9b93-42dc-be52-fc8b8082aac8	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
234c1ace-62a0-469c-a4e8-bb112b1f323d	HK1	1	ecb33362-9b93-42dc-be52-fc8b8082aac8	9f7ee2d2-efb9-48af-b185-da2fe145672c	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
ed22e180-af7b-40f4-b4f7-58a5967f1542	HK1	1	9f7ee2d2-efb9-48af-b185-da2fe145672c	96d7d27a-a9f0-44fb-b0bc-5098c93e7347	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
f9a365a5-0458-4f44-84d1-e232c4453e56	HK1	1	96d7d27a-a9f0-44fb-b0bc-5098c93e7347	a534bf0b-22ea-45fb-8048-8ba832c21640	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
c2fe5483-0dd7-4696-b41e-ac854d86ff54	HK1	1	a534bf0b-22ea-45fb-8048-8ba832c21640	8f8ef4a0-c83a-4463-816b-2a36c305224e	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
89fc723d-2b7e-4a38-b714-82f6b33102c6	HK1	1	8f8ef4a0-c83a-4463-816b-2a36c305224e	fdfe6b1c-be4a-4d33-9105-cf941127dd53	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
2bf74bad-3db3-4bbc-accd-a82bbdaa5c88	HK1	1	fdfe6b1c-be4a-4d33-9105-cf941127dd53	845d7c35-16b9-41a0-9e1f-38bfa465040e	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
36daf4be-4f96-44ae-b35e-e2ab2b3fb1c4	HK1	1	845d7c35-16b9-41a0-9e1f-38bfa465040e	2f7823fd-ea81-46fb-9846-cd0b8a5bc68b	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
51c99dfb-e97a-4fc6-842b-f6b7196e4592	HK1	1	2f7823fd-ea81-46fb-9846-cd0b8a5bc68b	3eeed178-b38c-4f10-99b2-03b42ffef850	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
db2925f4-9cbb-46d5-af9a-e110d34d0eae	HK1	1	3eeed178-b38c-4f10-99b2-03b42ffef850	0f06af73-21e6-44f3-9c36-a839ca2aa67e	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
29c86849-3cb4-4ada-b54c-9eecccbdc235	HK1	1	0f06af73-21e6-44f3-9c36-a839ca2aa67e	27dff445-9c50-40f6-9819-fcc187fd88ce	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
a1bf000d-7453-4ac5-b317-bbee22982858	HK1	1	27dff445-9c50-40f6-9819-fcc187fd88ce	2716887c-e326-46c3-8551-be671d0a24f3	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
97785977-a7b9-4dc4-bd26-c871f5fd1a28	HK1	1	2716887c-e326-46c3-8551-be671d0a24f3	4c1ac25c-d3ec-4da1-9daf-2ce5ae88d046	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
f9f046dd-e26b-4aa8-9f87-bafa58f3d689	HK1	1	4c1ac25c-d3ec-4da1-9daf-2ce5ae88d046	d8125a06-4ecf-4d8a-96cf-1ec24668b0df	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
11efe258-5da7-414e-97e2-f977d3137633	HK1	1	d8125a06-4ecf-4d8a-96cf-1ec24668b0df	7f44f1cc-1210-4b3f-bffb-71e202e890b5	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
58ee0151-5fd1-4f7f-bb11-f5d24ba6f91c	HK1	1	7f44f1cc-1210-4b3f-bffb-71e202e890b5	9fb4c531-95e7-4f7b-9c49-eec0ebe769c0	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
21de8d8d-d4cf-4da2-ac35-95dc86159b30	HK1	1	9fb4c531-95e7-4f7b-9c49-eec0ebe769c0	cbf82f2f-8d1f-491b-8c4c-73bae730f131	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
40e592ad-9c8b-4d6f-896d-d2e4fce2df3a	HK1	1	cbf82f2f-8d1f-491b-8c4c-73bae730f131	039a4927-7712-4120-8e00-a1b703e8116f	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
75968e94-6da1-438c-8323-356f0e60aaf1	HK1	1	039a4927-7712-4120-8e00-a1b703e8116f	96d9d09d-84bb-4dc8-81f0-0c57022bb627	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
0fc55ff7-8936-4823-af87-7522163d2c79	HK1	1	96d9d09d-84bb-4dc8-81f0-0c57022bb627	6aea5656-7af7-491a-9376-19358f3f1893	2026-07-28 14:01:07.429663+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 14:01:07.429663+00
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "ngay_cap_nhat", "nam_hoc", "createdat", "updatedat", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "giai_thich") FROM stdin;
1	BGH	tongquan	2026-08-17 22:20:01.457+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
2	BGH	qlchidoan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
3	BGH	doanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
4	BGH	ptdoanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
5	BGH	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
6	BGH	phancong	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
7	BGH	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
8	BGH	namtuan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
9	BGH	baocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
10	BGH	tonghopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
11	BGH	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
12	BGH	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
13	BGH	theodoi360	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:29:16.642643+00	2026-08-17 22:20:00.516603+00	t	f	f	f	
27	BTV	tongquan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
28	BTV	qlchidoan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
30	BTV	doanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
31	BTV	ptdoanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
32	BTV	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
33	BTV	phancong	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
34	BTV	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
35	BTV	namtuan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
36	BTV	baocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
37	BTV	tonghopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
38	BTV	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
39	BTV	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	f	\N
40	BTV	theodoi360	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	t	f	\N
42	BTV	phanquyen	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
43	BTV	saoluu	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	f	f	f	f	\N
44	BCH	tongquan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
45	BCH	qlchidoan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	t	f	\N
47	BCH	doanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	t	f	\N
48	BCH	ptdoanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
49	BCH	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
50	BCH	phancong	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
52	BCH	namtuan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
53	BCH	baocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
54	BCH	tonghopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
55	BCH	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
56	BCH	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
57	BCH	theodoi360	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	t	f	\N
58	GVCN	tongquan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
59	GVCN	qlchidoan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
62	GVCN	ptdoanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
63	GVCN	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
64	GVCN	phancong	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
65	GVCN	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
66	GVCN	namtuan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
67	GVCN	baocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
68	GVCN	tonghopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
69	GVCN	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
70	GVCN	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
71	GVCN	theodoi360	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
72	NC	tongquan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
73	NC	qlchidoan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
74	NC	doanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
75	NC	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
76	NC	phancong	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
77	NC	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
78	NC	namtuan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
79	NC	baocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
80	NC	tonghopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
81	NC	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
82	NC	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
83	NC	theodoi360	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	t	f	\N
84	DV	tongquan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
86	DV	ptdoanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
61	GVCN	doanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
85	DV	doanvien	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
51	BCH	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
87	DV	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
88	DV	phancong	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
89	DV	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
90	DV	namtuan	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
91	DV	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
92	DV	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
93	DV	theodoi360	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	t	t	t	\N
94	PH	tieuchitd	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
95	PH	chamdiem	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
96	PH	qlbaocao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
97	PH	qlnopbc	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	2026-08-17 22:20:00.516603+00	t	f	f	f	\N
178	BGH	giohoctap	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
179	BGH	xetthidua	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
180	BTV	giohoctap	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	t	t	f	\N
181	BTV	xetthidua	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	t	t	f	\N
182	BCH	giohoctap	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
183	BCH	xetthidua	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
184	GVCN	giohoctap	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
185	GVCN	xetthidua	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
186	GVCN	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	t	t	t	\N
187	BCH	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
188	BTV	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
189	NC	giohoctap	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	t	t	t	\N
190	NC	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
191	DV	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
192	PH	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	f	f	f	\N
193	BGH	thongbao	2026-08-17 22:20:01.459+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	\N	\N	t	t	t	t	\N
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."push_subscriptions" ("id", "user_id", "role", "chidoan_id", "subscription", "endpoint", "created_at") FROM stdin;
\.


--
-- Data for Name: ql_baocao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_baocao" ("id", "chu_de", "chu_de_phu", "tu_ngay", "den_ngay", "cho_phep_minh_chung", "doi_tuong_nop", "huong_dan", "ngay_tao", "nam_hoc_id", "hoc_ky", "config_noi_dung1", "config_noi_dung2", "config_noi_dung3", "config_noi_dung4", "config_noi_dung5", "config_noi_dung6", "config_noi_dung7", "config_noi_dung8", "config_noi_dung9", "config_noi_dung10", "allowed_file_types", "max_file_size") FROM stdin;
ff593611-6a18-4f9f-bf1b-e747ac484c1c	Báo cáo 1	\N	2026-07-23	2026-10-29	t	Tất cả	\N	2026-07-28 13:24:49.522919+00	0170a23d-4bb0-418a-8fc8-621f3bbc4988	HK1	{"type": "text", "label": "Nội dung 1", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 2", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 3", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 4", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 5", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 6", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 7", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 8", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 9", "enabled": true, "options": "", "required": false}	{"type": "text", "label": "Nội dung 10", "enabled": true, "options": "", "required": false}	image,video,pdf,doc	10
\.


--
-- Data for Name: ql_nop_bc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_nop_bc" ("id", "ql_bao_cao_id", "doanvien_id", "noi_dung1", "noi_dung2", "noi_dung3", "noi_dung4", "noi_dung5", "noi_dung6", "noi_dung7", "noi_dung8", "noi_dung9", "noi_dung10", "duong_dan_minh_chung", "ghi_chu", "trang_thai", "ngay_capnhat", "chi_doan_id", "danh_sach_anh", "vaitro_nop", "doituong_nop", "nguoi_tao_id") FROM stdin;
268e4e38-400b-42c0-9ded-544b2eeb8446	ff593611-6a18-4f9f-bf1b-e747ac484c1c	f035ea67-de6a-412a-8db0-0a1aa3fb6877	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Chờ duyệt	2026-08-15 09:33:44.396+00	6aea5656-7af7-491a-9376-19358f3f1893	https://pub-57eee16d09e14126b5578374360218ff.r2.dev/QLnopbaocaochuyende/2026-2027/HK1/Bao_cao_1/10A1/Admin/2026-2027_HK1_Bao_cao_1_10A1_Admin_3142.mp4, https://pub-57eee16d09e14126b5578374360218ff.r2.dev/QLnopbaocaochuyende/2026-2027/HK1/Bao_cao_1/10A1/Admin/2026-2027_HK1_Bao_cao_1_10A1_Admin_6517.xls	Admin	Admin	7f7eaeff-d667-40c5-9159-26e096ce0cc3
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat", "he_so_tru", "he_so_cong") FROM stdin;
6aea5656-7af7-491a-9376-19358f3f1893	10A1	Chiều	TN	11	Nguyễn Khánh Linh	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
14adc0ee-fdc9-4301-9e01-34fb739b8c16	10A2	Chiều	TN	10	Lê Hồ Hoài An	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
acc925e5-6206-4895-acdb-7e38a4e2e65b	10A3	Chiều	TN	9	Nguyễn Thị Trâm Anh	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
410a2919-b354-4c7e-996a-1dcbcd625bb2	10A4	Chiều	TN	8	Phạm Hà Anh	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
466bc1a7-c545-4aa6-ae55-b89d5e19eec8	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
890093ed-9c7f-4c0a-98bb-20f365a970c7	10A6	Chiều	XH	1	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
bb7f5708-2666-4eb0-83fd-f01d29d81bb8	10A7	Chiều	XH	2	Phạm Khánh Chi	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
b1185b4a-af94-4eca-ba55-9ee6189fd2cb	10A8	Chiều	XH	3	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
760beb12-74e2-4ac2-be1c-97562e9fc1c1	10A9	Chiều	XH	4	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
f54b64b0-4a30-4be9-991a-620af6966771	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
cdab1277-35b9-41d6-ac2a-9e00c2b46827	10A11	Chiều	XH	6	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
4ba0c710-1a9e-48ab-89f5-6764e9bbc78d	11C1	Chiều	TN	12	Lê Minh Phương	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
c9481035-336f-4435-9442-871952183193	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
c9a78ea0-851a-4eab-8599-19f1f216b6f6	11C3	Chiều	TN	14	Phạm Minh Anh	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
ecb33362-9b93-42dc-be52-fc8b8082aac8	11C4	Chiều	TN	15	Cù Hoàng Gia An	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
9f7ee2d2-efb9-48af-b185-da2fe145672c	11C5	Chiều	TN	16	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
96d7d27a-a9f0-44fb-b0bc-5098c93e7347	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
a534bf0b-22ea-45fb-8048-8ba832c21640	11C7	Sáng	XH	2	nguyễn hồng lai	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
8f8ef4a0-c83a-4463-816b-2a36c305224e	11C8	Sáng	XH	3	Nguyễn Trung Hiếu	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
fdfe6b1c-be4a-4d33-9105-cf941127dd53	11C9	Sáng	XH	4	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
845d7c35-16b9-41a0-9e1f-38bfa465040e	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
2f7823fd-ea81-46fb-9846-cd0b8a5bc68b	11C11	Sáng	XH	6	Bùi Thị Tường Vy	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
3eeed178-b38c-4f10-99b2-03b42ffef850	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
0f06af73-21e6-44f3-9c36-a839ca2aa67e	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
27dff445-9c50-40f6-9819-fcc187fd88ce	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
2716887c-e326-46c3-8551-be671d0a24f3	12B3	Sáng	TN	10	Nguyễn Gia Hân	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
4c1ac25c-d3ec-4da1-9daf-2ce5ae88d046	12B4	Sáng	TN	11	\N	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
d8125a06-4ecf-4d8a-96cf-1ec24668b0df	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
7f44f1cc-1210-4b3f-bffb-71e202e890b5	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
9fb4c531-95e7-4f7b-9c49-eec0ebe769c0	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
cbf82f2f-8d1f-491b-8c4c-73bae730f131	12B8	Sáng	XH	15	Quế Trân	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
039a4927-7712-4120-8e00-a1b703e8116f	12B9	Sáng	XH	16	Thành Tín	\N	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
96d9d09d-84bb-4dc8-81f0-0c57022bb627	12B10	Sáng	XH	17	Lê Tiến Công	Đoàn Thị Minh Hương	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:39:08.151011+00	2026-07-28 13:39:08.151011+00	1	1
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat", "cloudinary_cloud_name", "cloudinary_upload_preset", "cloudinary_api_key", "cloudinary_api_secret", "r2_account_id", "r2_access_key_id", "r2_secret_access_key", "r2_bucket_name", "r2_custom_domain", "show_class_select_gvcn", "diem_tot", "diem_kha", "diem_tb", "diem_yeu", "ti_trong_diem_tuan", "ti_trong_diem_hoc_tap") FROM stdin;
4df743d7-e712-4cbe-ab93-68a4bdf46335	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT Trần Phú	0		AQ.Ab8RN6IbkZlrB2PzrkavqCs_XSW019gjPGT1Yov9ZdWVu9ipMQ	0		\N	\N	\N	\N	23:55	30	Lỗi không báo cáo điểm tuần	f	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[U][C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:07:05.200313+00	2026-08-06 00:59:56.134315+00					396f3a9dd8e6309f74017ced953060d8	7f865d1e0d1c55d9b8ae58fc4df998a0	188ca9bea96fa950db9fa259b054b5bf719841162382f6f5a6fc0fbb5fe58b4e	luuhinhanh	https://pub-57eee16d09e14126b5578374360218ff.r2.dev	Không hiển thị	10	7	4	1	50	50
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat", "doanvien_id", "sl_dangnhap", "tg_truycap", "chidoan1111") FROM stdin;
759b5296-ec40-4035-9325-d9074b480b60	nguyenphamduonganha930g	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Phạm Dương Anh	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	f035ea67-de6a-412a-8db0-0a1aa3fb6877	0	\N	\N
f0ee5f95-63e4-4b93-bdbc-c7c1ef9d38e5	nguyenphamvanbe8sog1	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Phạm Văn Bé	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	596a1118-dde3-4bde-bb36-5cd64ea23f2c	0	\N	\N
1eab2146-c7e8-41af-8ab5-b9a1e7158f51	nguyenluongthanhbinh3teye	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Lương Thanh Bình	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	0cb70593-3e58-4247-a825-673ffd97c4d9	0	\N	\N
2dd89b81-0797-44ac-9c6c-42a9e740d421	nguyenbuingocdat8gnrg	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Bùi Ngọc Đạt	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	8d1ead77-ab5e-455f-bc46-311a217ed7a1	0	\N	\N
62e416fe-0493-4524-b599-043337a68720	nguyentrankhanhha13u6r	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn TRẦN KHÁNH HÀ	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	89787c05-61a5-4423-9207-6125c6e17a07	0	\N	\N
4326db08-cfac-441b-8255-e817aee24f8b	nguyennguyenconghau1tdht	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Công Hậu	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	a2cbd851-8587-4a84-ae5e-5c2dd4bb039d	0	\N	\N
3ff56139-926c-48e1-b4bc-ad692842f1c1	nguyennguyenduchieua2mrs	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Đức Hiếu	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	d3bed503-a490-4d45-998f-dab5e6bb499c	0	\N	\N
575d79f1-6515-493c-b7f6-b5afa396a1fd	nguyennguyenvanhieuwrgtd	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Văn Hiếu	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	ba5c0329-2c94-4156-a039-42a2847c7414	0	\N	\N
e0ced31c-b730-4638-9cf9-3d4cab34f86f	nguyenlethithuyhoaivi8db	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Lê Thị Thúy Hoài	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	64c9a6c6-318b-43b9-9154-ba30c0c8d809	0	\N	\N
d1853764-ea49-4353-9741-746231dda140	nguyendinhngockhanhhuyen9b58d	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Đinh Ngọc Khánh Huyền	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	0a848333-18cb-4e16-9f34-89b7222ac825	0	\N	\N
7f8d4138-d9c9-4088-9795-22bfcbecb2f2	nguyenphamquochungvvlvo	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Phạm Quốc Hưng	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	1023b8d0-1c96-40a3-89a9-892e48225944	0	\N	\N
28a9919f-fc10-493c-8b06-c83f42a61792	nguyendaovietkhanhtr1t8	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Đào Viết Khánh	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	73446302-f027-4c4d-ae73-4489b88145cf	0	\N	\N
a016940d-2a79-42c1-b42f-e5a19831a3b9	nguyennguyenquangkien45rpt	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Quang Kiên	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	6daec1b8-be20-4c18-b5ca-f6dc58588389	0	\N	\N
d4941bed-f7a6-48f5-9bd1-5616c13c724e	nguyennguyenkhanhlinhi8sub	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Khánh Linh	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	72167279-74bc-4e55-b82c-14224394cdaf	0	\N	\N
6a259142-ae98-484b-adb5-9f175985a3f7	nguyennguyenphilongq79ue	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Phi Long	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	ed3384d3-cace-43f1-b23b-9ec5b210948a	0	\N	\N
dfefecd4-e841-4da1-bfeb-cf1972e22ca8	nguyentranducluong9x5gv	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Trần Đức Lương	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	9f6fdd3e-2639-4ed4-bae1-d412d108adb8	0	\N	\N
b239a724-2832-4f8b-bad9-2d321b64e9e6	nguyenhothikhanhlyl54h1	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hồ Thị Khánh Ly	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	dcc0a96a-79a1-4706-81e4-80304bab6771	0	\N	\N
81e4cbd2-f0b7-4397-a916-b57d6a86aa80	nguyennguyenhoangbaominhgqeu6	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Hoàng Bảo Minh	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	19af9fa6-18b8-4ebe-bd23-7a395d9dcddd	0	\N	\N
b1510e6c-c956-42af-b9d4-913c2d7f2de5	nguyenhothungaq2o4x	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hồ Thu Nga	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	fa49e870-21cd-4dcd-91a2-169b780df5d3	0	\N	\N
e4970d2f-dbc6-4e6b-a378-2ef8bef2a6f8	nguyentrinhthihangngam4gxp	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Trịnh Thị Hằng Nga	DV	2026-08-19 14:24:09.138493+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.138493+00	e73f99c3-c8a5-4943-8f72-3ae965b84b07	0	\N	\N
45e21c95-8035-4a6b-bc03-33baee78125d	nguyennguyenlucngan0e0uw	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Lục Ngạn	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	2feacb20-f3c0-49e5-9e57-37e2d8d1fb24	0	\N	\N
b7cd9f96-434a-475a-87ee-9eb98b05da01	nguyenlehoangmyngocosom0	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Lê Hoàng Mỹ Ngọc	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	fd7f0142-44d7-4ca9-8095-08bfdfeaec02	0	\N	\N
6b59ded1-987f-44be-939b-67cb4e68c76d	nguyenlethibaongocmquay	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Lê Thị Bảo Ngọc	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	d2e884dd-5353-4c35-a596-dd70a045c071	0	\N	\N
d40a07af-f01e-4728-a1bf-9dd444f45a58	nguyencaoanhnhanwfjao	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Cao Anh Nhân	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	0990653e-3ad8-4f20-b390-ef739c0b0b09	0	\N	\N
dbd293fa-80ee-4bb7-84b6-ff82f721d4c1	nguyenlevothanhnhatm5pc8	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Lê Võ Thanh Nhật	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	59700d22-2bc0-4a5d-bae6-4af4cf58146a	0	\N	\N
8ad1be11-8a4e-4b79-ba51-00c965b8ecf3	nguyendangthithuphuongy7ott	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Đặng Thị Thu Phương	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	b62342dd-07bc-4e9c-aad2-f1803450734f	0	\N	\N
5f772d1a-ef55-4f6a-a985-513aaa54b6be	nguyendobaoquangb9iao	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Đỗ Bảo Quang	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	d09d798a-4051-499a-a226-48f7e920cdc2	0	\N	\N
7455083b-fea5-401c-8f4a-8b6cd20d6292	nguyenhohuuquangd73mk	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hồ Hữu Quang	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	f1c26ce8-50b2-491e-bcfa-a87610902994	0	\N	\N
14207743-858b-46fb-89c5-7bc9f3fbcc32	nguyenhokhacanhquanhqo2x	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hô Khắc Anh Quân	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	5584edc9-f202-4b53-be04-0a850dcff28e	0	\N	\N
1fb0bae5-1e6f-44de-888a-a96affb4d1cc	nguyenhosyquantz7a9	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hồ Sỹ Quân	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	8c762b34-a838-4009-8f3c-0034df09b5b5	0	\N	\N
21f4f344-06cb-47cb-a7a2-fc18165d8932	nguyenphamvunhuquynhl48h4	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Phạm Vũ Như Quỳnh	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	ad486648-57ab-40db-8c85-94150b12543b	0	\N	\N
cb723535-fa73-4101-8018-5570d5a03011	nguyennguyenngoclanthanh62qs7	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Ngọc Lan Thanh	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	a809ced4-8ba7-4115-8d23-e99711cc74f9	0	\N	\N
ce054378-fac1-453d-80a1-1826c48a1726	nguyenvohanhthaooxadp	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Võ Hạnh Thảo	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	d9a7b926-0a8c-4f47-b619-6433096d9f58	0	\N	\N
8d6ea24c-1ce0-454b-89b8-9363a2905912	nguyentranhongthezjf5y	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Trần Hồng Thế	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	53f81aec-18c5-4c23-984e-cc009ba9b302	0	\N	\N
97ed70bb-b865-400f-acf9-6e71ef4250ec	nguyenduongducthinh3hwkz	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Dương Đức Thịnh	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	4b6b37f6-5360-4fdf-aca7-fc5782fedcc9	0	\N	\N
8477d409-f43d-4101-bfda-5c9dfae81ff1	nguyenphanngocthinhdehwc	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Phan Ngọc Thịnh	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	64dd0e90-5341-4595-8a5e-57ecb1f570ac	0	\N	\N
f350e036-8f7c-493b-8e29-6d6e805a73a2	nguyenbuithilythumj5q8	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Bùi Thị Lý Thu	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	2cd94e92-31ba-4139-90c6-b448721d0e5a	0	\N	\N
7a007c29-b863-4333-a181-0d8b54421f1a	nguyenhonguyenkhanhtrangbsr1f	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hồ Nguyễn Khánh Trang	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	28b3d6b7-b037-4102-98b4-ee7519cb2938	0	\N	\N
d95e407e-6ef5-4568-92d3-a5581cd2c10a	nguyenhothithuytrangl6tmh	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Hồ Thị Thùy Trang	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	14d0fdc8-e161-484a-8120-92d269df733c	0	\N	\N
ee9964f3-c256-4662-a99f-3029cbddf45e	nguyenlethithuytrang9h310	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Lê Thị Thùy Trang	DV	2026-08-19 14:24:09.313+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.313+00	eff799ee-7290-48cf-94b6-72491e9031bd	0	\N	\N
bae7a199-3a25-43c4-94ea-694af1acfcae	nguyennguyenthihuyentrangexrmk	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Thị Huyền Trang	DV	2026-08-19 14:24:09.451721+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.451721+00	b7385976-b56a-4495-88cf-7f4ae9f53cce	0	\N	\N
e7b36300-5579-42f0-ab24-4e010c84b0e4	nguyennguyentranhuyentranglq4if	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Trần Huyền Trang	DV	2026-08-19 14:24:09.451721+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.451721+00	9622ebdc-c7ce-4c27-ae8f-010b7f0f5c30	0	\N	\N
cd984edb-083b-4d2f-9aa6-c7176a95d431	nguyennguyenquoctrongz50xx	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Nguyễn Quốc Trọng	DV	2026-08-19 14:24:09.451721+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.451721+00	c00ef7bc-85d4-47e8-adc9-932a01533d8f	0	\N	\N
b2a89052-32f6-4008-9c70-44232a2f503d	nguyendoantuongvy03b62	$2b$10$WIRmRA99SA9MzjoZYEGfJeM5BtnKNoeOj0LJaFaTc.uP3HdLL4nHy	Nguyễn Đoàn Tường Vy	DV	2026-08-19 14:24:09.451721+00	6aea5656-7af7-491a-9376-19358f3f1893	2026-08-19 14:24:09.451721+00	43ed91ed-89eb-4c51-b2aa-86801215b5da	0	\N	\N
7f7eaeff-d667-40c5-9159-26e096ce0cc3	Admin	$2a$10$3vMdAtZIpRCGbbJeYBuh8uf5ShESvTov0guPgg6P5DCx0W8UTEbI2	Quản trị	Admin	2026-08-19 14:23:42.449153+00	\N	2026-07-28 12:52:32.331275+00	\N	11	2026-08-19 21:23:42+00	\N
\.


--
-- Data for Name: theodoi360; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."theodoi360" ("id", "nguoi_to_cao_id", "doan_vien_vi_pham_id", "tieu_chi_id", "chi_tiet_vi_pham", "danh_sach_hinh_anh", "url_video", "trang_thai", "nam_hoc_id", "tuan_id", "ngay_vi_pham", "ngay_tao", "hoc_ky", "phan_hoi_bi_to_cao", "phan_hoi_lop", "minh_chung_drive") FROM stdin;
3bc7054a-eebe-43f4-a4da-14caeb59654f	f035ea67-de6a-412a-8db0-0a1aa3fb6877	8d1ead77-ab5e-455f-bc46-311a217ed7a1	a3443d80-a667-47f7-bc0a-b06f01367aa9	lỗi	["https://pub-57eee16d09e14126b5578374360218ff.r2.dev/TheoDoi360/2026-2027/HK1/T1/10A1/NguyenBuiNgocDat/2026-08-06/Cupchaoco/NguyenBuiNgocDat_10A1_2026-2027_HK1_T1_NEW_hinh1_fdkg.png", "https://pub-57eee16d09e14126b5578374360218ff.r2.dev/TheoDoi360/2026-2027/HK1/T1/10A1/NguyenBuiNgocDat/2026-08-06/Cupchaoco/NguyenBuiNgocDat_10A1_2026-2027_HK1_T1_ID3bc7054a_hinh1_s2my.xls", "https://pub-57eee16d09e14126b5578374360218ff.r2.dev/TheoDoi360/2026-2027/HK1/T1/10A1/NguyenBuiNgocDat/2026-08-06/Cupchaoco/NguyenBuiNgocDat_10A1_2026-2027_HK1_T1_ID3bc7054a_hinh2_s2my.docx"]	https://pub-57eee16d09e14126b5578374360218ff.r2.dev/TheoDoi360/2026-2027/HK1/T1/10A1/NguyenBuiNgocDat/2026-08-06/Cupchaoco/NguyenBuiNgocDat_10A1_2026-2027_HK1_T1_ID3bc7054a_video1_s2my.mp4	cho_duyet	0170a23d-4bb0-418a-8fc8-621f3bbc4988	9c0f7ec3-b9f5-4691-83e6-820f37ac260c	2026-08-06	2026-08-06 01:34:45.301501+00	HK1			\N
\.


--
-- Data for Name: thongbao_hethong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_hethong" ("id", "title", "content", "sender", "target_role", "target_chidoan_id", "target_user_id", "created_at", "read_by") FROM stdin;
5e9d6b28-1668-4ce4-bac0-e3b4b9e1e0c0	Có đợt báo cáo chuyên đề mới	Chủ đề: Báo cáo 1. Thời gian triển khai từ ngày 23/07/2026 - Hạn hoàn thành: 29/10/2026. Vui lòng nộp báo cáo đúng hạn!	Hệ thống tự động	all	\N	\N	2026-07-28 13:24:50.446+00	[]
\.


--
-- Data for Name: thongbao_riengbiet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_riengbiet" ("id", "namhoc_id", "sender_id", "sender_name", "sender_role", "title", "content", "attachments", "target_roles", "target_chidoan_ids", "start_at", "end_at", "created_at", "updated_at", "read_by") FROM stdin;
7b30ffb6-dbb3-433a-9281-8f87d6ed3741	0170a23d-4bb0-418a-8fc8-621f3bbc4988	7f7eaeff-d667-40c5-9159-26e096ce0cc3	Quản trị	Admin	1	1	[{"key": "QLthongbaoriengbiet/2026-2027/Admin/1_6152/Baocaothidua_tuan_36_1659.docx", "url": "https://pub-57eee16d09e14126b5578374360218ff.r2.dev/QLthongbaoriengbiet/2026-2027/Admin/1_6152/Baocaothidua_tuan_36_1659.docx", "name": "Baocaothidua_tuan_36.docx", "size": 14725, "type": "file"}, {"key": "QLthongbaoriengbiet/2026-2027/Admin/1_6152/canh1_8360.jpg", "url": "https://pub-57eee16d09e14126b5578374360218ff.r2.dev/QLthongbaoriengbiet/2026-2027/Admin/1_6152/canh1_8360.jpg", "name": "canh1.jpg", "size": 214301, "type": "image"}, {"key": "QLthongbaoriengbiet/2026-2027/Admin/1_6152/Copy_of_Thao_HKII_18_tuan_-_the_2_1999.xls", "url": "https://pub-57eee16d09e14126b5578374360218ff.r2.dev/QLthongbaoriengbiet/2026-2027/Admin/1_6152/Copy_of_Thao_HKII_18_tuan_-_the_2_1999.xls", "name": "Copy of Thao HKII_18 tuan - the 2.xls", "size": 93696, "type": "file"}]	{all}	{all}	2026-08-15 09:41:27.049+00	2126-07-22 09:41:27.049+00	2026-08-15 09:41:26.521782+00	2026-08-15 09:41:27.049+00	{}
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
acd345cf-0db3-430e-8b5e-3f52060a8608	CD01	Điểm 10		Thành tích	0	3		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
2a1718db-b5f0-40e7-9fac-9f407503b53c	CD02	Điểm 9		Thành tích	0	2		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
a1de3c22-7d39-40a8-91d2-1ee1bb78afca	CD03	Nhặt được của rơi		Thành tích	0	5		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
841d9c96-9269-411f-84d2-e480cbbfb47e	TC01	Đi học muộn2		Vi phạm	2	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
9e3bac33-fb91-4468-a00b-e68d2ea8ac2c	TC02	Cúp tiết		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
a3443d80-a667-47f7-bc0a-b06f01367aa9	TC03	Cúp chào cờ		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
6960027b-26be-4e80-9c14-b5b1e43d6436	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
33d72374-de6a-4e44-9010-c4d9b4579fca	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
bce19cac-56ec-499d-8962-9cf47c87adf5	TC06	Không sơ vin		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
58b31307-d9ab-45e3-a2a7-538dac7e7525	TC07	Không bảng tên		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
00e99ed8-a223-48c7-9fb4-47beca6e4308	TC08	Sai đồng phục		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
dfe75070-5477-4fb6-9649-c65f6597f419	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
1f608387-09fe-4b2e-9164-58ca5bca94f1	TC10	Không quai dép		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
8e8431ed-d6ae-410a-ac87-dce1374aef63	TC11	Đi dép lê		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
7fd3a5bf-b42b-4ea7-82fe-afe70040b8c1	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
79d790a5-dc64-4b5b-8359-8701e9f20883	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
9fa8fa35-1a14-4b31-a809-f887d6ae099c	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
94b95bbb-da53-49a7-a06b-86e8962661ef	TC15	Sơn móng tay		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
2455e2e8-e11b-4a85-b6ce-2f7fd60b2358	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
108780aa-c212-4dba-b566-03cc2cc58b1b	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
eaea5764-c9dd-454a-a83b-55d84acfac29	TC18	chở quá số người qui định		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
ff4530ef-2c74-4f9c-9d0f-aec12ac1d627	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
62316a29-0b9a-405c-9afd-6450f4f2831e	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
7a9151af-3bb0-414f-b066-46e8a93d3453	TC21	Hút thuốc lá		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
c9882642-2c9d-4fc3-b257-7a6a8c6dc149	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
97ff98a4-8263-4fa5-ad18-9ad785a016a5	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
5be8a1c8-84c9-49c9-8b78-f4ac68d2fb82	TC24	Có thái độ vô lễ với CB, CNV nhà trường:		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
ebc60284-bdff-452c-9822-c38ba41a20aa	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
b84ccaa8-dd0c-4e88-b5a1-88ce4d02c812	TC26	Vệ sinh muộn		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
13b1c59c-2986-44ad-b82a-e1f0064099b9	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
5b2142b2-b573-4372-a1db-f0c22946932c	TC28	Học sinh vứt rác không đúng qui định		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
e4212b40-83ee-4a3a-803c-5c8127aa59c9	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
2a648cf8-936d-40ed-9f07-b49bd46ffd90	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
4f1a4cfb-1ef3-46fb-89e9-c92f5c0fec1b	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
8d386a1d-bc67-4a26-a3a0-03756806927e	TC32	Không cất ghế ngồi chào cờ		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
309e3fe0-79f3-49e4-9538-7794f5e1991d	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
90fb3f8b-689f-4d86-b595-446f2430f84e	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
50847795-9570-44de-82f0-368e678b1485	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
f037694d-e92b-461b-bced-148a0deb0414	TC36	Học sinh vào lớp muộn trong giữa các tiết học		Vi phạm	0.5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
c41ad6dc-6f33-41fc-9d9c-cc84eaefecdb	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
51e0c261-bac7-4ce4-b95f-bc53198b0400	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
7f25b567-70b8-44f5-9f13-b632d0ce2833	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
4ec56880-3924-4c95-a414-a6e9dbd34f05	TC40	Đi chấm trễ		Vi phạm	2	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
d8c79a25-f379-45f4-ac9d-b300cd90f447	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
ab11c682-5672-4d92-bc6c-d623501865d2	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
55763951-52b4-4bd9-9288-40ca505965cb	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
7ccbf418-fb90-4dfb-b673-dfd79b235ee2	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
26b376b3-2f72-4703-934f-256afcdb024d	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
f4cf5471-7739-40da-b90f-394d80507b26	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
d0d8b0e5-129c-47d2-902c-825f2f50fa26	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
08fa00e5-7acd-4c48-8e5a-96640f57b273	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
e697e395-26c1-4937-b703-7ec0056565d1	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
0ed8a8df-ca35-45d5-8443-8b16018ff2c6	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
b67947a6-ab3d-416f-b10f-e15e1561517d	TC52	Không đi chấm		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
c4a5054a-32f3-4cb1-9392-2ab99b03ea32	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
7f8a04ab-ff84-40b5-a1b1-e0621ddc275e	TC56	Cúp 1 tiết		Vi phạm	5	0		2026-07-28 13:44:41.317225+00	HK1	0170a23d-4bb0-418a-8fc8-621f3bbc4988	2026-07-28 13:44:41.317225+00
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
9c0f7ec3-b9f5-4691-83e6-820f37ac260c	0170a23d-4bb0-418a-8fc8-621f3bbc4988	HK1	1	2026-07-28	2026-11-03	t	f	2026-07-28 13:05:01.853593+00		2026-07-28 13:07:05.685479+00
\.


--
-- Data for Name: vanban_doan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."vanban_doan" ("id", "category", "title", "drive_link", "updated_at", "updated_by") FROM stdin;
3fd0ed62-b833-4ee6-9eb6-f5feb1281bf4	ke_hoach	Kế hoạch		2026-08-18 04:38:21.848236+00	
7ace72aa-e945-4188-b449-477661cdaaad	thong_bao	Thông báo		2026-08-18 04:38:21.848236+00	
08bee0b1-7232-4825-8743-458c34679f79	nghi_quyet	Nghị quyết		2026-08-18 04:38:21.848236+00	
009d3b66-c417-4f77-b8aa-2c8498be67cb	bao_cao	Báo cáo		2026-08-18 04:38:21.848236+00	
c654d9e0-884d-49a1-90b2-f37a2cb11409	tai_chinh	Tài chính		2026-08-18 04:38:21.848236+00	
afc66152-1df1-4960-8bb3-4a4e40a82c4d	van_ban_khac	Văn bản khác		2026-08-18 04:38:21.848236+00	
\.


--
-- Data for Name: xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."xet_thidua" ("id", "namhoc_id", "hoc_ky", "chidoan_id", "tong_diem_cham_tuan", "tieuchi_1", "tieuchi_2", "tieuchi_3", "tieuchi_4", "tieuchi_5", "tieuchi_6", "tieuchi_7", "tieuchi_8", "tieuchi_9", "tieuchi_10", "tong_diem", "xep_hang", "danh_hieu_thi_dua", "ghi_chu", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_18; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_18" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_19; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_19" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_20; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_20" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_21; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_21" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_22; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_22" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_23; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_23" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_24; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_24" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-07-28 12:48:54
20211116045059	2026-07-28 12:48:54
20211116050929	2026-07-28 12:48:54
20211116051442	2026-07-28 12:48:54
20211116212300	2026-07-28 12:48:54
20211116213355	2026-07-28 12:48:54
20211116213934	2026-07-28 12:48:54
20211116214523	2026-07-28 12:48:54
20211122062447	2026-07-28 12:48:54
20211124070109	2026-07-28 12:48:54
20211202204204	2026-07-28 12:48:54
20211202204605	2026-07-28 12:48:54
20211210212804	2026-07-28 12:48:54
20211228014915	2026-07-28 12:48:54
20220107221237	2026-07-28 12:48:54
20220228202821	2026-07-28 12:48:54
20220312004840	2026-07-28 12:48:54
20220603231003	2026-07-28 12:48:54
20220603232444	2026-07-28 12:48:54
20220615214548	2026-07-28 12:48:54
20220712093339	2026-07-28 12:48:54
20220908172859	2026-07-28 12:48:54
20220916233421	2026-07-28 12:48:54
20230119133233	2026-07-28 12:48:54
20230128025114	2026-07-28 12:48:54
20230128025212	2026-07-28 12:48:54
20230227211149	2026-07-28 12:48:54
20230228184745	2026-07-28 12:48:54
20230308225145	2026-07-28 12:48:54
20230328144023	2026-07-28 12:48:54
20231018144023	2026-07-28 12:48:54
20231204144023	2026-07-28 12:48:54
20231204144024	2026-07-28 12:48:54
20231204144025	2026-07-28 12:48:54
20240108234812	2026-07-28 12:48:54
20240109165339	2026-07-28 12:48:54
20240227174441	2026-07-28 12:48:54
20240311171622	2026-07-28 12:48:54
20240321100241	2026-07-28 12:48:54
20240401105812	2026-07-28 12:48:54
20240418121054	2026-07-28 12:48:54
20240523004032	2026-07-28 12:48:54
20240618124746	2026-07-28 12:48:54
20240801235015	2026-07-28 12:48:54
20240805133720	2026-07-28 12:48:54
20240827160934	2026-07-28 12:48:54
20240919163303	2026-07-28 12:48:54
20240919163305	2026-07-28 12:48:54
20241019105805	2026-07-28 12:48:54
20241030150047	2026-07-28 12:48:54
20241108114728	2026-07-28 12:48:54
20241121104152	2026-07-28 12:48:54
20241130184212	2026-07-28 12:48:54
20241220035512	2026-07-28 12:48:54
20241220123912	2026-07-28 12:48:54
20241224161212	2026-07-28 12:48:54
20250107150512	2026-07-28 12:48:54
20250110162412	2026-07-28 12:48:54
20250123174212	2026-07-28 12:48:54
20250128220012	2026-07-28 12:48:54
20250506224012	2026-07-28 12:48:54
20250523164012	2026-07-28 12:48:54
20250714121412	2026-07-28 12:48:54
20250905041441	2026-07-28 12:48:54
20251103001201	2026-07-28 12:48:54
20251120212548	2026-07-28 12:48:54
20251120215549	2026-07-28 12:48:54
20260218120000	2026-07-28 12:48:54
20260326120000	2026-07-28 12:48:54
20260514120000	2026-07-28 12:48:54
20260527120000	2026-07-28 12:48:54
20260528120000	2026-07-28 12:48:54
20260603120000	2026-07-28 12:48:54
20260605120000	2026-07-28 12:48:54
20260606110000	2026-07-28 12:48:54
20260616120000	2026-07-28 12:48:54
20260624120000	2026-07-28 12:48:54
20260626120000	2026-07-28 12:48:54
20260706120000	2026-07-28 12:48:54
20260707120000	2026-07-28 12:48:54
20260709120000	2026-07-28 12:48:54
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter", "selected_columns") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type", "versioning_status") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-07-28 11:15:58.554651
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-07-28 11:15:58.607309
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-07-28 11:15:58.613249
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-07-28 11:15:58.65119
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-07-28 11:15:58.671122
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-07-28 11:15:58.67535
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-07-28 11:15:58.681124
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-07-28 11:15:58.686093
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-07-28 11:15:58.690381
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-07-28 11:15:58.695193
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-07-28 11:15:58.702339
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-07-28 11:15:58.708979
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-07-28 11:15:58.714457
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-07-28 11:15:58.719158
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-07-28 11:15:58.724281
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-07-28 11:15:58.762138
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-07-28 11:15:58.767819
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-07-28 11:15:58.771843
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-07-28 11:15:58.7758
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-07-28 11:15:58.781457
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-07-28 11:15:58.78719
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-07-28 11:15:58.79362
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-07-28 11:15:58.809549
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-07-28 11:15:58.82099
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-07-28 11:15:58.82563
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-07-28 11:15:58.82978
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-07-28 11:15:58.833953
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-07-28 11:15:58.838754
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-07-28 11:15:58.842414
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-07-28 11:15:58.845897
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-07-28 11:15:58.849728
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-07-28 11:15:58.853385
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-07-28 11:15:58.857278
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-07-28 11:15:58.864387
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-07-28 11:15:58.870492
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-07-28 11:15:58.874683
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-07-28 11:15:58.878264
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-07-28 11:15:58.881818
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-07-28 11:15:58.886562
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-07-28 11:15:58.898146
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-07-28 11:15:58.902082
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-07-28 11:15:58.905808
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-07-28 11:15:58.909673
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-07-28 11:15:58.913503
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-07-28 11:15:58.917532
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-07-28 11:15:58.922158
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-07-28 11:15:58.933829
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-07-28 11:15:58.938444
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-07-28 11:15:58.942546
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-07-28 11:15:58.961941
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-07-28 11:15:58.96675
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-07-28 11:15:59.320236
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-07-28 11:15:59.321974
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-07-28 11:15:59.331906
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-07-28 11:15:59.334422
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-07-28 11:15:59.336156
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-07-28 11:15:59.341325
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-07-28 11:15:59.347118
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-07-28 11:15:59.351301
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-07-28 11:15:59.356241
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-07-28 11:15:59.361055
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-08-11 13:05:59.020034
62	object-versioning-core	0b855f00ff3be0bfca91efee02a9858912491a9a	2026-08-21 00:06:37.319726
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata", "archived_at", "is_delete_marker", "is_versioned") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 44, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 193, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: gio_hoc_tap gio_hoc_tap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "gio_hoc_tap_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_endpoint_key" UNIQUE ("endpoint");


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_pkey" PRIMARY KEY ("id");


--
-- Name: ql_baocao ql_baocao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "ql_baocao_pkey" PRIMARY KEY ("id");


--
-- Name: ql_nop_bc ql_nop_bc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "ql_nop_bc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: theodoi360 theodoi360_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_hethong thongbao_hethong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_hethong"
    ADD CONSTRAINT "thongbao_hethong_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_riengbiet thongbao_riengbiet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "thongbao_riengbiet_pkey" PRIMARY KEY ("id");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua unique_cauhinh_namhoc_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "unique_cauhinh_namhoc_hocky" UNIQUE ("namhoc_id", "hoc_ky");


--
-- Name: chamdiem unique_chamdiem_record; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "unique_chamdiem_record" UNIQUE ("namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "chidoan_id");


--
-- Name: gio_hoc_tap unique_chidoan_tuan_namhoc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "unique_chidoan_tuan_namhoc" UNIQUE ("chidoan_id", "tuan_id", "namhoc_id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: xet_thidua unique_xet_thidua_chidoan_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "unique_xet_thidua_chidoan_hocky" UNIQUE ("namhoc_id", "hoc_ky", "chidoan_id");


--
-- Name: vanban_doan vanban_doan_category_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."vanban_doan"
    ADD CONSTRAINT "vanban_doan_category_key" UNIQUE ("category");


--
-- Name: vanban_doan vanban_doan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."vanban_doan"
    ADD CONSTRAINT "vanban_doan_pkey" PRIMARY KEY ("id");


--
-- Name: xet_thidua xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_18 messages_2026_08_18_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_18"
    ADD CONSTRAINT "messages_2026_08_18_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_19 messages_2026_08_19_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_19"
    ADD CONSTRAINT "messages_2026_08_19_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_20 messages_2026_08_20_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_20"
    ADD CONSTRAINT "messages_2026_08_20_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_21 messages_2026_08_21_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_21"
    ADD CONSTRAINT "messages_2026_08_21_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_22 messages_2026_08_22_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_22"
    ADD CONSTRAINT "messages_2026_08_22_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_23 messages_2026_08_23_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_23"
    ADD CONSTRAINT "messages_2026_08_23_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_24 messages_2026_08_24_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_24"
    ADD CONSTRAINT "messages_2026_08_24_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages"
    ADD CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_cauhinh_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_cauhinh_thidua_namhoc_hocky" ON "public"."cauhinh_tieuchi_xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: idx_chamdiem_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_hocky" ON "public"."chamdiem" USING "btree" ("hocky");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_lopcham_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_lopcham_chamlop" ON "public"."chamdiem" USING "btree" ("lopcham", "chamlop");


--
-- Name: idx_chamdiem_optimization_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_optimization_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_optimization_namhoc_hocky_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_hocky_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_chamdiem_optimization_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "tuan");


--
-- Name: idx_chamdiem_thongke; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thongke" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan", "chamlop");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_namhoc_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_namhoc_isdefault_true" ON "public"."namhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_ql_nop_bc_baocao; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_baocao" ON "public"."ql_nop_bc" USING "btree" ("ql_bao_cao_id");


--
-- Name: idx_ql_nop_bc_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_chidoan" ON "public"."ql_nop_bc" USING "btree" ("chi_doan_id");


--
-- Name: idx_ql_nop_bc_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_doanvien" ON "public"."ql_nop_bc" USING "btree" ("doanvien_id");


--
-- Name: idx_qlchidoan_optimization_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_optimization_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_doanvien_id" ON "public"."taikhoan" USING "btree" ("doanvien_id");


--
-- Name: idx_taikhoan_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_role" ON "public"."taikhoan" USING "btree" ("role");


--
-- Name: idx_taikhoan_username_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_username_lower" ON "public"."taikhoan" USING "btree" ("lower"("username"));


--
-- Name: idx_theodoi360_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_doanvien" ON "public"."theodoi360" USING "btree" ("doan_vien_vi_pham_id");


--
-- Name: idx_theodoi360_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_namhoc_tuan" ON "public"."theodoi360" USING "btree" ("nam_hoc_id", "tuan_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tuan_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_tuan_isdefault_true" ON "public"."tuanhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_optimization_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_optimization_namhoc_hocky" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_xet_thidua_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_chidoan" ON "public"."xet_thidua" USING "btree" ("chidoan_id");


--
-- Name: idx_xet_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_namhoc_hocky" ON "public"."xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_18_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_18_inserted_at_topic_idx" ON "realtime"."messages_2026_08_18" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_19_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_19_inserted_at_topic_idx" ON "realtime"."messages_2026_08_19" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_20_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_20_inserted_at_topic_idx" ON "realtime"."messages_2026_08_20" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_21_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_21_inserted_at_topic_idx" ON "realtime"."messages_2026_08_21" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_22_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_22_inserted_at_topic_idx" ON "realtime"."messages_2026_08_22" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_23_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_23_inserted_at_topic_idx" ON "realtime"."messages_2026_08_23" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_24_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_24_inserted_at_topic_idx" ON "realtime"."messages_2026_08_24" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_selec" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter", COALESCE("selected_columns", '{}'::"text"[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_08_18_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_18_inserted_at_topic_idx";


--
-- Name: messages_2026_08_18_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_18_pkey";


--
-- Name: messages_2026_08_19_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_19_inserted_at_topic_idx";


--
-- Name: messages_2026_08_19_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_19_pkey";


--
-- Name: messages_2026_08_20_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_20_inserted_at_topic_idx";


--
-- Name: messages_2026_08_20_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_20_pkey";


--
-- Name: messages_2026_08_21_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_21_inserted_at_topic_idx";


--
-- Name: messages_2026_08_21_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_21_pkey";


--
-- Name: messages_2026_08_22_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_22_inserted_at_topic_idx";


--
-- Name: messages_2026_08_22_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_22_pkey";


--
-- Name: messages_2026_08_23_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_23_inserted_at_topic_idx";


--
-- Name: messages_2026_08_23_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_23_pkey";


--
-- Name: messages_2026_08_24_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_24_inserted_at_topic_idx";


--
-- Name: messages_2026_08_24_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_24_pkey";


--
-- Name: taikhoan trg_1_kiem_tra_an_ninh_taikhoan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_1_kiem_tra_an_ninh_taikhoan" BEFORE INSERT OR DELETE OR UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"();


--
-- Name: taikhoan trg_2_tu_dong_bam_mat_khau_taikhoan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_2_tu_dong_bam_mat_khau_taikhoan" BEFORE INSERT OR UPDATE OF "password" ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"();


--
-- Name: taikhoan trg_3_dong_bo_taikhoan_sang_auth_users; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_3_dong_bo_taikhoan_sang_auth_users" AFTER INSERT OR DELETE OR UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"();


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_chidoan" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_namhoc" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_tuan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_tuan" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id") ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ql_baocao fk_ql_baocao_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "fk_ql_baocao_namhoc" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: ql_nop_bc fk_ql_nop_bc_baocao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_baocao" FOREIGN KEY ("ql_bao_cao_id") REFERENCES "public"."ql_baocao"("id") ON DELETE CASCADE;


--
-- Name: ql_nop_bc fk_ql_nop_bc_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_chidoan" FOREIGN KEY ("chi_doan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE SET NULL;


--
-- Name: ql_nop_bc fk_ql_nop_bc_doanvien; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_doanvien" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE SET NULL;


--
-- Name: theodoi360 theodoi360_doan_vien_vi_pham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_doan_vien_vi_pham_fkey" FOREIGN KEY ("doan_vien_vi_pham_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_nam_hoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nam_hoc_fkey" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: theodoi360 theodoi360_nguoi_to_cao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nguoi_to_cao_fkey" FOREIGN KEY ("nguoi_to_cao_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_tieu_chi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tieu_chi_fkey" FOREIGN KEY ("tieu_chi_id") REFERENCES "public"."tieuchitd"("id");


--
-- Name: theodoi360 theodoi360_tuan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tuan_fkey" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id");


--
-- Name: xet_thidua xet_thidua_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: xet_thidua xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: vanban_doan Admin có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin có full quyền" ON "public"."vanban_doan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text"])));


--
-- Name: taikhoan Admin toàn quyền quản trị bảng taikhoan; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin toàn quyền quản trị bảng taikhoan" ON "public"."taikhoan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['admin'::"text", 'btv'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['admin'::"text", 'btv'::"text"])));


--
-- Name: cauhinh_tieuchi_xet_thidua Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: doanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."doanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: dotptdoanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."dotptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: namhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."namhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: phancong Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."phancong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ql_baocao Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."ql_baocao" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: qlchidoan Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."qlchidoan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tieuchitd Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tieuchitd" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tuanhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tuanhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: thongbao_hethong Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."thongbao_hethong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: xet_thidua Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ptdoanvien Admin, BTV, BCH có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"])));


--
-- Name: thongbao_riengbiet Admin, BTV, BGH, GVCN có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"])));


--
-- Name: chamdiem Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."chamdiem" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: gio_hoc_tap Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: doanvien BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."doanvien" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: qlchidoan BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."qlchidoan" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: duytricsdl Cho phép mọi người cập nhật duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl" FOR UPDATE USING (true) WITH CHECK (true);


--
-- Name: duytricsdl Cho phép mọi người xem duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl" FOR SELECT USING (true);


--
-- Name: phanquyen Cho phép xem bảng phân quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem bảng phân quyền" ON "public"."phanquyen" FOR SELECT TO "authenticated" USING (true);


--
-- Name: qlchidoan Cho phép xem danh sách chi đoàn; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách chi đoàn" ON "public"."qlchidoan" FOR SELECT USING (true);


--
-- Name: namhoc Cho phép xem danh sách năm học; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách năm học" ON "public"."namhoc" FOR SELECT USING (true);


--
-- Name: tuanhoc Cho phép xem danh sách tuần học; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách tuần học" ON "public"."tuanhoc" FOR SELECT USING (true);


--
-- Name: taikhoan Cho phép xem danh sách tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách tài khoản" ON "public"."taikhoan" FOR SELECT TO "authenticated" USING ((("public"."get_auth_role"() = ANY (ARRAY['admin'::"text", 'btv'::"text", 'bgh'::"text"])) OR ("id" = "auth"."uid"()) OR ("lower"("username") = "lower"("split_part"(COALESCE("auth"."email"(), ''::"text"), '@'::"text", 1)))));


--
-- Name: github_settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."github_settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: phanquyen Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."phanquyen" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: cauhinh_tieuchi_xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: chamdiem Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."chamdiem" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: doanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."doanvien" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: dotptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: gio_hoc_tap Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: github_settings Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."github_settings" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: phancong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."phancong" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: ptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: ql_baocao Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ql_baocao" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: settings Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."settings" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: thongbao_hethong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: thongbao_riengbiet Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: tieuchitd Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."tieuchitd" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: vanban_doan Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."vanban_doan" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."xet_thidua" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: taikhoan Zero-Trust: Sửa dữ liệu cá nhân; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Zero-Trust: Sửa dữ liệu cá nhân" ON "public"."taikhoan" FOR UPDATE TO "authenticated" USING ((("id" = "auth"."uid"()) AND ((( SELECT "count"(*) AS "count"
   FROM "auth"."mfa_factors"
  WHERE (("mfa_factors"."user_id" = "auth"."uid"()) AND ("mfa_factors"."status" = 'verified'::"auth"."factor_status"))) = 0) OR (("auth"."jwt"() ->> 'aal'::"text") = 'aal2'::"text")))) WITH CHECK (("id" = "auth"."uid"()));


--
-- Name: taikhoan Zero-Trust: Xem dữ liệu tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Zero-Trust: Xem dữ liệu tài khoản" ON "public"."taikhoan" FOR SELECT TO "authenticated" USING (((("id" = "auth"."uid"()) OR ("upper"((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text")) = 'ADMIN'::"text")) AND ((( SELECT "count"(*) AS "count"
   FROM "auth"."mfa_factors"
  WHERE (("mfa_factors"."user_id" = "auth"."uid"()) AND ("mfa_factors"."status" = 'verified'::"auth"."factor_status"))) = 0) OR (("auth"."jwt"() ->> 'aal'::"text") = 'aal2'::"text"))));


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: duytricsdl; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."duytricsdl" ENABLE ROW LEVEL SECURITY;

--
-- Name: gio_hoc_tap; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."gio_hoc_tap" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."push_subscriptions" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_baocao; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_baocao" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_nop_bc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_nop_bc" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: theodoi360; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."theodoi360" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_hethong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_hethong" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_riengbiet; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_riengbiet" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: vanban_doan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."vanban_doan" ENABLE ROW LEVEL SECURITY;

--
-- Name: xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."activity_logs" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: duytricsdl Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."duytricsdl" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: push_subscriptions Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: ql_nop_bc Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: theodoi360 Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."theodoi360" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "fn_dong_bo_taikhoan_sang_auth_users"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() TO "service_role";


--
-- Name: FUNCTION "fn_kiem_tra_an_ninh_taikhoan"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() TO "service_role";


--
-- Name: FUNCTION "fn_tu_dong_bam_mat_khau_taikhoan"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() TO "service_role";


--
-- Name: FUNCTION "get_auth_chidoan_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_doanvien_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "service_role";


--
-- Name: FUNCTION "get_secure_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "service_role";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "save_user_backup_codes"("p_encrypted_codes" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "verify_and_consume_backup_code"("p_code" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "service_role";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "wal2json_escape_identifier"("name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements_info" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "cauhinh_tieuchi_xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "gio_hoc_tap"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "anon";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "authenticated";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "push_subscriptions"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."push_subscriptions" TO "anon";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "authenticated";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "service_role";


--
-- Name: TABLE "ql_baocao"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_baocao" TO "anon";
GRANT ALL ON TABLE "public"."ql_baocao" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_baocao" TO "service_role";


--
-- Name: TABLE "ql_nop_bc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_nop_bc" TO "anon";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "theodoi360"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."theodoi360" TO "anon";
GRANT ALL ON TABLE "public"."theodoi360" TO "authenticated";
GRANT ALL ON TABLE "public"."theodoi360" TO "service_role";


--
-- Name: TABLE "thongbao_hethong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_hethong" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "service_role";


--
-- Name: TABLE "thongbao_riengbiet"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "vanban_doan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."vanban_doan" TO "anon";
GRANT ALL ON TABLE "public"."vanban_doan" TO "authenticated";
GRANT ALL ON TABLE "public"."vanban_doan" TO "service_role";


--
-- Name: TABLE "xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."xet_thidua" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_08_18"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_18" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_18" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_19"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_19" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_19" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_20"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_20" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_20" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_21"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_21" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_21" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_22"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_22" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_22" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_23"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_23" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_23" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_24"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_24" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_24" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict Cj9SycSQCubBve0IrgppadKLHFSN2JhxiM7brCvaclmipM9tmNZHTJJcTp8IGqP

